/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.lendoo.merchant_lend_repayment;

import com.fabmagnati.lendoo.Datasource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class MerchantLendRepaymentService {

    public MerchantLendRepaymentResponse merchantLendReplacement(Map<String, String> headers, MerchantLendRepaymentRequest request) throws SQLException {
        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall("{call proc_merch_lend_repayment_ins(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {

            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errorText", Types.VARCHAR);

            callableStatement.setInt("merchant_id", request.getMerchantId());
            callableStatement.setString("edi_date", request.getEdiDate());
            callableStatement.setBigDecimal("edi_date", request.getCurrency());
            callableStatement.setBigDecimal("currency", request.getCurrency());
            callableStatement.setBigDecimal("edi_amount", request.getEdiAmount());
            callableStatement.setBigDecimal("orig_loan_amount", request.getOriginalLoanAmount());
            callableStatement.setBigDecimal("remaining_loan_amount", request.getRemainingLoanAmount());
            callableStatement.setInt("loan_term", request.getLoanTerm());
            callableStatement.setString("data_insert_dt", request.getDataInsertDate());

            callableStatement.execute();

            MerchantLendRepaymentResponse response = new MerchantLendRepaymentResponse();

            response.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));

            return response;
        }
    }

}
