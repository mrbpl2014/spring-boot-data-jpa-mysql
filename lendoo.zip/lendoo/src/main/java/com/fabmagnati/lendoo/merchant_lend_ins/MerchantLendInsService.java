/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.lendoo.merchant_lend_ins;

import com.fabmagnati.lendoo.Datasource;
import com.fabmagnati.lendoo.merchant_lend_repayment.MerchantLendRepaymentRequest;
import com.fabmagnati.lendoo.merchant_lend_repayment.MerchantLendRepaymentResponse;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class MerchantLendInsService {

    public MerchantLendInsResponse merchantLendingIns(Map<String, String> headers, MerchantLendInsRequest request) throws SQLException {
        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall("{call proc_merchant_lending_ins(?, ?, ?, ?, ?, ?, ?, ?)}");) {

            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errorText", Types.VARCHAR);

            callableStatement.setInt("pi_merchant_id", request.getMerchantId());
            callableStatement.setString("pi_lending_req_date", request.getLendingReqDate());
            callableStatement.setString("pi_lending_status", request.getLendingStatus());
            callableStatement.setBigDecimal("pi_lending_amount", request.getLendingAmount());
            callableStatement.setString("pi_reason ", request.getReason());
            callableStatement.setString("pi_lent_date", request.getLentDate());

            callableStatement.execute();

            MerchantLendInsResponse response = new MerchantLendInsResponse();

            response.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));

            return response;
        }
    }

}
