/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.lendoo;

import com.fabmagnati.lendoo.merchant_lend_ins.MerchantLendInsRequest;
import com.fabmagnati.lendoo.merchant_lend_ins.MerchantLendInsResponse;
import com.fabmagnati.lendoo.merchant_lend_ins.MerchantLendInsService;
import com.fabmagnati.lendoo.merchant_lend_repayment.MerchantLendRepaymentRequest;
import com.fabmagnati.lendoo.merchant_lend_repayment.MerchantLendRepaymentResponse;
import com.fabmagnati.lendoo.merchant_lend_repayment.MerchantLendRepaymentService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import java.sql.SQLException;
import java.util.Map;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LendooController {

    private static final Logger logger = LoggerFactory.getLogger(LendooController.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    MerchantLendRepaymentService merchantLendRepaymentService;

    @Autowired
    MerchantLendInsService merchantLendInsService;

    @PostMapping("/merchantLendRepayment")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")
    })
    public MerchantLendRepaymentResponse merchantLendRepayment(@RequestHeader Map<String, String> headers, @Valid @RequestBody MerchantLendRepaymentRequest request) throws SQLException, JsonProcessingException {
        MerchantLendRepaymentResponse response = merchantLendRepaymentService.merchantLendReplacement(headers, request);

        logger.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                objectMapper.writeValueAsString(response));

        return response;

    }

    @PostMapping("/merchantLendingIns")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")
    })
    public MerchantLendInsResponse merchantLendingIns(@RequestHeader Map<String, String> headers, @Valid @RequestBody MerchantLendInsRequest request) throws SQLException, JsonProcessingException {
        MerchantLendInsResponse response = merchantLendInsService.merchantLendingIns(headers, request);

        logger.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                objectMapper.writeValueAsString(response));

        return response;

    }
}
