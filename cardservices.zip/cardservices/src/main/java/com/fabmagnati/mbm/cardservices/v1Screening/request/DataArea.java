package com.fabmagnati.mbm.cardservices.v1Screening.request;

public class DataArea {
	private CustomerDetails customerDetails;
	private String customerType;
	private String enquiryRefNumber;
	private String channelId;
	private String productId;

	public String getChannelId() {
		return channelId;
	}

	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}

	public String getCustomerType() {
		return customerType;
	}

	public String getEnquiryRefNumber() {
		return enquiryRefNumber;
	}

	public String getProductId() {
		return productId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public void setEnquiryRefNumber(String enquiryRefNumber) {
		this.enquiryRefNumber = enquiryRefNumber;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

}
