package com.fabmagnati.mbm.cardservices.createCard;

public class AllocateCardResponse {
	private String cardId;
	private String cardNumber;
	private String emirates;
	private Integer errorCode;
	private String errorText;
	private String IBAN;
	private String occupation;
	private String salutation;
	private String screeningStatus;

	public AllocateCardResponse() {
	}

	public String getCardId() {
		return cardId;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public String getEmirates() {
		return emirates;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public String getIBAN() {
		return IBAN;
	}

	public String getOccupation() {
		return occupation;
	}

	public String getSalutation() {
		return salutation;
	}

	public String getScreeningStatus() {
		return screeningStatus;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public void setEmirates(String emirates) {
		this.emirates = emirates;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public void setIBAN(String IBAN) {
		this.IBAN = IBAN;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public void setScreeningStatus(String screeningStatus) {
		this.screeningStatus = screeningStatus;
	}

	@Override
	public String toString() {
		return "AllocateCardResponse [errorText=" + errorText + ", cardId=" + cardId + ", cardNumber=" + cardNumber
				+ ", IBAN=" + IBAN + ", errorCode=" + errorCode + ", salutation=" + salutation + ", occupation="
				+ occupation + ", emirates=" + emirates + "]";
	}

}
