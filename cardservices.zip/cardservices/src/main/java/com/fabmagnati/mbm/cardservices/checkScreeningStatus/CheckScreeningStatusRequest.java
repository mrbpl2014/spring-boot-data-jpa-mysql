package com.fabmagnati.mbm.cardservices.checkScreeningStatus;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class CheckScreeningStatusRequest {
	@Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
	@NotBlank
	private String correlationId;

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

}
