/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.notify_card_transactions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NotifyCardTransactionRequest {
    @NotEmpty
    @NotNull
    private String cardId;
    @NotEmpty
    @NotNull
    private String transactionSource;
    private String terminalId;
    private String merchantId;
    private String rrn;
    @NotEmpty
    @NotNull
    private String indicator;
    private BigDecimal transactionAmount;
    @NotEmpty
    @NotNull
    private String transactionCurrency;
    private BigDecimal equivalentAmount;
    @NotEmpty
    @NotNull
    private String equivalentCurrency;
    private String authorizationCode;
    private BigDecimal feeAmount;
    private String feeDescription;
    @NotEmpty
    @NotNull
    private String desc1;
    private String desc2;
    private String mcc;
    private String merchantName;
    private String merchantLocation;
    private Timestamp transactionDateTime;
    private String sourceTxnReferenceNo;
    @NotEmpty
    @NotNull
    private String typeOfTransaction;

}
