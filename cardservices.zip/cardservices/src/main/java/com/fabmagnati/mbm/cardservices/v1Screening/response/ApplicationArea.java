package com.fabmagnati.mbm.cardservices.v1Screening.response;

public class ApplicationArea {
	public String correlationId;
	public String countryOfOrigin;
	public String creationDateTime;
	public String interfaceID;
	public String requiredExecutionDate;
	public String senderAuthorizationComments;
	public String senderAuthorizationID;
	public String senderBranchId;
	public String senderId;
	public String senderReferenceID;
	public String senderUserId;
	public String transactionDateTime;
	public String transactionId;

	public String transactionTimeZone;

	public String getCorrelationId() {
		return correlationId;
	}

	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public String getCreationDateTime() {
		return creationDateTime;
	}

	public String getInterfaceID() {
		return interfaceID;
	}

	public String getRequiredExecutionDate() {
		return requiredExecutionDate;
	}

	public String getSenderAuthorizationComments() {
		return senderAuthorizationComments;
	}

	public String getSenderAuthorizationID() {
		return senderAuthorizationID;
	}

	public String getSenderBranchId() {
		return senderBranchId;
	}

	public String getSenderId() {
		return senderId;
	}

	public String getSenderReferenceID() {
		return senderReferenceID;
	}

	public String getSenderUserId() {
		return senderUserId;
	}

	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getTransactionTimeZone() {
		return transactionTimeZone;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public void setCreationDateTime(String creationDateTime) {
		this.creationDateTime = creationDateTime;
	}

	public void setInterfaceID(String interfaceID) {
		this.interfaceID = interfaceID;
	}

	public void setRequiredExecutionDate(String requiredExecutionDate) {
		this.requiredExecutionDate = requiredExecutionDate;
	}

	public void setSenderAuthorizationComments(String senderAuthorizationComments) {
		this.senderAuthorizationComments = senderAuthorizationComments;
	}

	public void setSenderAuthorizationID(String senderAuthorizationID) {
		this.senderAuthorizationID = senderAuthorizationID;
	}

	public void setSenderBranchId(String senderBranchId) {
		this.senderBranchId = senderBranchId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public void setSenderReferenceID(String senderReferenceID) {
		this.senderReferenceID = senderReferenceID;
	}

	public void setSenderUserId(String senderUserId) {
		this.senderUserId = senderUserId;
	}

	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setTransactionTimeZone(String transactionTimeZone) {
		this.transactionTimeZone = transactionTimeZone;
	}

	@Override
	public String toString() {
		return "ApplicationArea{" + "correlationId='" + correlationId + '\'' + ", countryOfOrigin='" + countryOfOrigin
				+ '\'' + ", creationDateTime=" + creationDateTime + ", interfaceID='" + interfaceID + '\''
				+ ", requiredExecutionDate=" + requiredExecutionDate + ", senderUserId='" + senderUserId + '\''
				+ ", senderBranchId='" + senderBranchId + '\'' + ", senderId='" + senderId + '\''
				+ ", transactionDateTime=" + transactionDateTime + ", transactionId='" + transactionId + '\''
				+ ", transactionTimeZone='" + transactionTimeZone + '\'' + ", senderAuthorizationID='"
				+ senderAuthorizationID + '\'' + ", senderReferenceID='" + senderReferenceID + '\''
				+ ", senderAuthorizationComments='" + senderAuthorizationComments + '\'' + '}';
	}
}