package com.fabmagnati.mbm.cardservices.card_replacement;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardReplacementRequest {
    @NotNull
    @NotEmpty
    private String cardId;

    private String iban;

    @NotNull
    @NotEmpty
    private String reason;


}
