package com.fabmagnati.mbm.cardservices.v1Screening.response;

public class DataArea {
	private String dateFilter;
	private String statusBehaviour;
	private String statusName;
	private String systemID;

	public String getDateFilter() {
		return dateFilter;
	}

	public String getStatusBehaviour() {
		return statusBehaviour;
	}

	public String getStatusName() {
		return statusName;
	}

	public String getSystemID() {
		return systemID;
	}

	public void setDateFilter(String dateFilter) {
		this.dateFilter = dateFilter;
	}

	public void setStatusBehaviour(String statusBehaviour) {
		this.statusBehaviour = statusBehaviour;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
}
