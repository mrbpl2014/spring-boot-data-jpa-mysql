package com.fabmagnati.mbm.cardservices.load_limit_validation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoadLimitValidationRequest {
    private int inqMode;
    private BigDecimal transactionAmount;
    private String value;


}
