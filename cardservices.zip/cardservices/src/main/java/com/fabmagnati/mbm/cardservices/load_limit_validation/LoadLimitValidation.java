package com.fabmagnati.mbm.cardservices.load_limit_validation;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.load_limit_validation.LoadLimitValidationRequest;
import com.fabmagnati.mbm.cardservices.load_limit_validation.LoadLimitValidationResponse;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class LoadLimitValidation {

    public LoadLimitValidationResponse loadLimitValidation(Map<String, String> headers,
                                                           LoadLimitValidationRequest request) throws SQLException {
        try (Connection connection = Datasource.getConnection(); CallableStatement callableStatement = connection.prepareCall("{call proc_get_loadlimits_wallet(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {
            callableStatement.registerOutParameter("@po_vc_cardid", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_availablebal", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_currentbal", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_cardstatus", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_productdesc", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_producttype", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_firstnameenglish", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_middlenameenglish", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_lastnameenglish", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_topupcounter", Types.INTEGER);
            callableStatement.registerOutParameter("@po_nm_possibleloadamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_totalfeeamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_IBAN", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);
            
            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
            callableStatement.setShort("@pi_ti_inqmode", (short) request.getInqMode());
            callableStatement.setString("@pi_vc_value", request.getValue());
//            callableStatement.setBigDecimal("@pi_nm_txnamount", request.getTransactionAmount());
            callableStatement.execute();

            LoadLimitValidationResponse response = new LoadLimitValidationResponse();
            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorcode")));
            response.setErrorText(callableStatement.getString("@po_vc_errortext"));
            response.setAvailableBalance(callableStatement.getBigDecimal("@po_nm_availablebal"));
            response.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_currentbal"));
            response.setCardId(callableStatement.getString("@po_vc_cardid"));
            response.setIban(callableStatement.getString("@po_vc_IBAN"));
            response.setCardStatus(callableStatement.getString("@po_vc_cardstatus"));
            response.setProductDescription(callableStatement.getString("@po_vc_productdesc"));
            response.setProductType(callableStatement.getInt("@po_i_producttype"));
            response.setFirstName(callableStatement.getString("@po_vc_firstnameenglish"));
            response.setMiddleName(callableStatement.getString("@po_vc_middlenameenglish"));
            response.setLastName(callableStatement.getString("@po_vc_lastnameenglish"));
            response.setTopupCounter(callableStatement.getInt("@po_i_topupcounter"));
            response.setPossibleLoadAmount(callableStatement.getBigDecimal("@po_nm_possibleloadamount"));
            response.setTotalFeeAmount(callableStatement.getBigDecimal("@po_nm_totalfeeamount"));
            return response;
        }
    }

}
