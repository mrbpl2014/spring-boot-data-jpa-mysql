package com.fabmagnati.mbm.cardservices.kycUpload;

public class KycUploadRequest {
	private String cardId;
	private String content;

	public KycUploadRequest() {
	}

	public String getCardId() {
		return cardId;
	}

	public String getContent() {
		return content;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
