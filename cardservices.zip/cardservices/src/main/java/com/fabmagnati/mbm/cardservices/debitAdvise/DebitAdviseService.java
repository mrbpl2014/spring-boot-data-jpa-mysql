package com.fabmagnati.mbm.cardservices.debitAdvise;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;

public class DebitAdviseService {

	public static DebitAdviseResponse processTransaction(Map<String, String> headers, DebitAdviseRequest request)
			throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection.prepareCall(
						"{call proc_channel_debit_transaction(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@pio_vc_cardid", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_nm_avlbalamount", Types.NUMERIC);
			callableStatement.registerOutParameter("@po_nm_curbalamount", Types.NUMERIC);
			callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
			callableStatement.setShort("@pi_si_txntype", request.getTransactionType());
			callableStatement.setString("@pio_vc_cardid", request.getCardId());
			callableStatement.setString("@pi_vc_txnidentifier", request.getTransactionId());
			callableStatement.setString("@pi_vc_org_txnidentifier", request.getOriginalTransactionId());
			callableStatement.setShort("@pi_ti_txnsource", request.getTxnSource());
			callableStatement.setShort("@pi_si_rev_flag", request.getReversalFlag());
			callableStatement.setString("@pi_vc_desc1", request.getDesc());
			callableStatement.setShort("@pi_si_feetype#", request.getFeeType());
			callableStatement.setBigDecimal("@pi_nm_feeamount", request.getFeeAmount());
			callableStatement.setBigDecimal("@pi_nm_txnamount", request.getTxnAmount());
			callableStatement.setString("@pi_vc_txncurrcode", request.getTxnCurrCode());
			callableStatement.setBigDecimal("@pi_nm_billamount", request.getBillAmount());
			callableStatement.setString("@pi_vc_billcurrcode", request.getBillCurrCode());
			callableStatement.setBigDecimal("@pi_nm_txnrate", request.getTxnRate());
			callableStatement.setString("@pi_vc_retrievalrefno", request.getRetrivalRefNo());
			callableStatement.execute();
			DebitAdviseResponse response = new DebitAdviseResponse();
			response.setAvailableBalance(callableStatement.getBigDecimal("@po_nm_avlbalamount"));
			response.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_curbalamount"));
			response.setCardId(callableStatement.getString("@pio_vc_cardid"));
			response.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
			response.setErrorText(callableStatement.getString("@po_vc_errortext"));
			return response;
		}
	}

}
