package com.fabmagnati.mbm.cardservices.util;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum EndPoint {
    BALANCE_ENQUIRY("/getBalance"),
    UPDATE_CUSTOMER_DATA("/updateCustomerdata"),
    TRANSACTION_HISTORY("/getTransactionHistory"),
    CARD_REPLACEMENT("/cardReplacement"),
    LOAD_LIMIT_VALIDATION("/getLoadLimits"),
    POS_LIMIT_INQUIRY("/getPosLimits"),
    POS_LIMIT_UPDATE("/updatePosLimits"),
    SPEND_LIMIT_VALIDATION("/getSpendLimits"),
    NOTIFY_CARD_TRANSACTION("/notifyCardTxns")

    ;
  private final String urlPath;
}
