/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.notify_card_transactions;

import com.fabmagnati.mbm.cardservices.notify_card_transactions.NotifyCardTransactionRequest;
import com.fabmagnati.mbm.cardservices.notify_card_transactions.NotifyCardTransactionResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class NotifyCardTransactionService {

    private static final Logger logger = LoggerFactory.getLogger(NotifyCardTransactionService.class);

    @Autowired
    private RestTemplate restTemplate;

    public NotifyCardTransactionResponse notifyCardTransactions(Map<String, String> headers, NotifyCardTransactionRequest request) {

        String internalMBMUrl = System.getenv("MBM_WEBHOOK");
        logger.info("MBM_URL " + internalMBMUrl);
        logger.info("payload " + request);

        return restTemplate.postForObject(internalMBMUrl, request, NotifyCardTransactionResponse.class);

    }

}
