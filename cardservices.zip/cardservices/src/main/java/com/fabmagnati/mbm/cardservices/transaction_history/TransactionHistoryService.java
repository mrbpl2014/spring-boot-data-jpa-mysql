package com.fabmagnati.mbm.cardservices.transaction_history;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.sql.*;
import java.util.Map;

@Service
public class TransactionHistoryService {

    public TransactionHistoryResponse getTransactionHistory(Map<String, String> headers, @Valid TransactionHistoryRequest request) throws SQLException {
        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall(
                "{call proc_get_cardtxnhistory_mbm(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {
//            callableStatement.registerOutParameter("@po_dt_txndatetime", Types.TIMESTAMP);
//            callableStatement.registerOutParameter("@po_vc_desc1", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_vc_desc2", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_nm_txnamount", Types.NUMERIC);
//            callableStatement.registerOutParameter("@po_c_crdbflag", Types.CHAR);
//            callableStatement.registerOutParameter("@po_nm_currentbal", Types.NUMERIC);
//            callableStatement.registerOutParameter("@po_vc_txnsourcedesc", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_vc_txntypedesc", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_vc_txncurrcode", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_vc_billcurrcode", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_nm_billamount", Types.NUMERIC);
//            callableStatement.registerOutParameter("@po_vc_txnrefno", Types.VARCHAR);
//            callableStatement.registerOutParameter("@po_vc_mcc", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);

            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifer", headers.get("clientidentifier"));
            callableStatement.setShort("@pi_ti_requesttype", (short) request.getRequestType());
            callableStatement.setString("@pi_vc_cardid", request.getCardId());
            callableStatement.setString("@pi_c_fromdate", request.getStartDate());
            callableStatement.setString("@pi_c_todate", request.getEndDate());
            callableStatement.setInt("@pi_i_retrievecount", request.getNumberOfTxns());
            callableStatement.execute();

            if ((callableStatement.getInt("@po_i_errorcode") != 0)) {
                throw new ElpasoException(callableStatement.getInt("@po_i_errorcode"),
                        callableStatement.getString("@po_vc_errortext"), headers.get("transactionid"));
            }

            TransactionHistoryResponse response = new TransactionHistoryResponse();
            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorcode")));
            response.setErrorText(callableStatement.getString("@po_vc_errortext"));
//            response.setTxnDateTime(String.valueOf(callableStatement.getTimestamp("@po_dt_txndatetime")));
//            response.setDesc1(callableStatement.getString("@po_vc_desc1"));
//            response.setDesc2(callableStatement.getString("@po_vc_desc2"));
//            response.setTransactionAmount(callableStatement.getBigDecimal("@po_nm_txnamount"));
//            response.setCreditDebitFlag(callableStatement.getString("@po_c_crdbflag"));
//            response.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_currentbal"));
//            response.setTransactionSourceDesc(callableStatement.getString("@po_vc_txnsourcedesc"));
//            response.setTransactionTypeDesc(callableStatement.getString("@po_vc_txntypedesc"));
//            response.setTransactionCurrencyCode(callableStatement.getString("@po_vc_txncurrcode"));
//            response.setBilledCurrencyCode(callableStatement.getString("@po_vc_billcurrcode"));
//            response.setBilledAmount(callableStatement.getBigDecimal("@po_nm_billamount"));
//            response.setTransactionReferenceNumber(callableStatement.getString("@po_vc_txnrefno"));
//            response.setMcc(callableStatement.getString("@po_vc_mcc"));
            return response;
        }
    }
}
