package com.fabmagnati.mbm.cardservices.v1Screening.response;

public class MetaData {
	public String dateFormat;
}
