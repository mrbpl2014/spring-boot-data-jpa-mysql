/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.balace_enquiry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author Hariharasudhan
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BalanceEnquiryResponse {

    private String errorCode;
    private String errorText;
    private String cardId;
    private BigDecimal availableBalance;
    private BigDecimal currentBalance;
    private BigDecimal lastTopUpAmount;
    private String lastTopUpDate;
    private BigDecimal lastTransactionAmount;
    private String lastTransactionDate;
    private String cardNumber;
    private String iban;

}
