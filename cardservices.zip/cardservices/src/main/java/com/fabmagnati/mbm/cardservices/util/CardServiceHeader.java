package com.fabmagnati.mbm.cardservices.util;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum CardServiceHeader {
    CHANNEL_ID("channelid"),
    COUNTRY_OF_ORIGIN("countryoforigin"),
    TRANSACTION_ID("transactionid"),
    CLIENT_IDENTIFIER("clientidentifier"),
    TRANSACTION_DATE_TIME("transactiondatetime"),
    TRANSACTION_TIME_ZONE("transactiontimezone");

    private final String header;


}
