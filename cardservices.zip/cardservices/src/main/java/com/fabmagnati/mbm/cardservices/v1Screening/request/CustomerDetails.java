package com.fabmagnati.mbm.cardservices.v1Screening.request;

import java.util.List;

public class CustomerDetails {
	private ContactDetails contactDetails;
	private String customerSegment;
	private String firstName;
	private String gender;
	private List<Identification> identification;
	private String lastName;
	private String name;
	private String profession;
	private String salutation;
	private String companyName;
	private String countryOfDomicile;
	private String nationalIdExpiry;
	private String nationality;
	private String enquiryRefNumber;
	private String customerType;

	public String getCompanyName() {
		return companyName;
	}

	public ContactDetails getContactDetails() {
		return contactDetails;
	}

	public String getCountryOfDomicile() {
		return countryOfDomicile;
	}

	public String getCustomerSegment() {
		return customerSegment;
	}

	public String getCustomerType() {
		return customerType;
	}

	public String getEnquiryRefNumber() {
		return enquiryRefNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getGender() {
		return gender;
	}

	public List<Identification> getIdentification() {
		return identification;
	}

	public String getLastName() {
		return lastName;
	}

	public String getName() {
		return name;
	}

	public String getNationalIdExpiry() {
		return nationalIdExpiry;
	}

	public String getNationality() {
		return nationality;
	}

	public String getProfession() {
		return profession;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}

	public void setCountryOfDomicile(String countryOfDomicile) {
		this.countryOfDomicile = countryOfDomicile;
	}

	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public void setEnquiryRefNumber(String enquiryRefNumber) {
		this.enquiryRefNumber = enquiryRefNumber;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setIdentification(List<Identification> identification) {
		this.identification = identification;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNationalIdExpiry(String nationalIdExpiry) {
		this.nationalIdExpiry = nationalIdExpiry;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

}
