package com.fabmagnati.mbm.cardservices.createCard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.DuplicateCardException;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import com.fabmagnati.mbm.cardservices.v1Screening.FircoScreeningRequest;
import com.fabmagnati.mbm.cardservices.v1Screening.FircoScreeningResponse;
import com.fabmagnati.mbm.cardservices.v1Screening.request.ApplicationArea;
import com.fabmagnati.mbm.cardservices.v1Screening.request.ContactDetails;
import com.fabmagnati.mbm.cardservices.v1Screening.request.CustomerDetails;
import com.fabmagnati.mbm.cardservices.v1Screening.request.DataArea;
import com.fabmagnati.mbm.cardservices.v1Screening.request.Identification;
import com.fabmagnati.mbm.cardservices.v1Screening.request.Phone;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateCardService {

	private final static Logger LOGGER = LoggerFactory.getLogger(CreateCardService.class);

	public static CreateCardResponse processRequest(Map<String, String> headers, CreateCardRequest request)
			throws SQLException, IOException {
		AllocateCardResponse allocateCardResponse = allocateCard(headers, request);
		FircoScreeningResponse screenCardResponse = initiateScreening(headers, request, allocateCardResponse);
		CreateCardResponse createCardResponse = updateCardStatus(headers, request, allocateCardResponse,
				screenCardResponse);
		return createCardResponse;
	}

	public static AllocateCardResponse allocateCard(Map<String, String> headers, CreateCardRequest request)
			throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection.prepareCall(
						"{call proc_i_customerBoarding_wallet_MBM(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@pio_vc_amlstatus", Types.VARCHAR);
			callableStatement.registerOutParameter("@pio_vc_cardid", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_IBAN", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_cardNumber", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_errorCode ", Types.INTEGER);
			callableStatement.registerOutParameter("@po_vc_version", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_salutation", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_occupation", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_emirates", Types.VARCHAR);

			callableStatement.setString("@pi_vc_ref#", headers.get("transactionid"));
			callableStatement.setShort("@pi_ti_txnsource", Short.valueOf(headers.get("transactionsource")));
			callableStatement.setShort("@pi_si_txntype", (short) 0);
			callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
			callableStatement.setShort("@pi_ti_idtype", request.getIdType());
			callableStatement.setString("@pi_vc_id#", request.getIdNumber());
			callableStatement.setString("@pi_vc_idexpdate", request.getIdExpiryDate());
			callableStatement.setString("@pi_vc_idissuecountry", request.getIdIssueCountryId());
			callableStatement.setString("@pi_c_reqtype", "NC");
			callableStatement.setString("@pi_c_custtype", request.getCustomerType());
			callableStatement.setShort("@pi_ti_arrowregistered", request.getArrowRegistered());
			callableStatement.setShort("@pi_ti_documentsverified ", request.getDocumentsVerified());
			callableStatement.setInt("@pi_i_salutation", request.getPrefixTitle());
			callableStatement.setString("@pi_vc_firstnameenglish", request.getFirstName());
			callableStatement.setString("@pi_vc_middlenameenglish", request.getMiddleName());
			callableStatement.setString("@pi_vc_lastnameenglish", request.getLastName());
			callableStatement.setString("@pi_vc_embossednameenglish", request.getEmbossedName());
			callableStatement.setString("@pi_vc_dob", request.getDob());
			callableStatement.setString("@pi_vc_nationality", request.getNationality());
			callableStatement.setString("@pi_vc_countryofresidence", request.getCountryOfResidence());
			callableStatement.setString("@pi_vc_address1", request.getAddressLine1());
			callableStatement.setString("@pi_vc_address2", request.getAddressLine2());
			callableStatement.setString("@pi_vc_address3", request.getAddressLine3());
			callableStatement.setString("@pi_vc_address4", request.getAddressLine4());
			callableStatement.setString("@pi_vc_city", request.getCity());
			callableStatement.setString("@pi_vc_countrycode", request.getCountryCode());
			callableStatement.setString("@pi_vc_postalcode", request.getPostalCode());
			callableStatement.setString("@pi_vc_mobile", request.getMobile());
			callableStatement.setString("@pi_vc_email", request.getEmail());
			callableStatement.setString("@pi_vc_occupation", request.getOccupation());
			callableStatement.setString("@pi_vc_walletid", request.getWalletId());
			callableStatement.setString("@pio_vc_amlstatus", "");
			callableStatement.setString("@pi_vc_gender", request.getGender());
			callableStatement.setShort("@pi_ti_emirates", request.getEmirates());
			callableStatement.setString("@pi_c_cardType", request.getCardType());
			callableStatement.setInt("@pi_i_productType", request.getProductType());
			callableStatement.setString("@pi_vc_pcif", request.getPcif());
			callableStatement.setString("@pi_vc_VisaExpiryDate", request.getVisaExpiryDate());
			callableStatement.setString("@pi_vc_birthPlace", request.getBirthPlace());
			callableStatement.setString("@pi_vc_companyName", request.getCompanyName());
			callableStatement.setString("@pio_vc_cardid", request.getCardId());

			AllocateCardResponse allocateCardResponse = new AllocateCardResponse();
			allocateCardResponse.setErrorText(callableStatement.getString("@po_vc_errortext"));
			allocateCardResponse.setCardId(callableStatement.getString("@pio_vc_cardid"));
			allocateCardResponse.setCardNumber(callableStatement.getString("@po_vc_cardNumber"));
			allocateCardResponse.setIBAN(callableStatement.getString("@po_vc_IBAN"));
			allocateCardResponse.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
			allocateCardResponse.setSalutation(callableStatement.getString("@po_vc_salutation"));
			allocateCardResponse.setOccupation(callableStatement.getString("@po_vc_occupation"));
			allocateCardResponse.setEmirates(callableStatement.getString("@po_vc_emirates"));
			allocateCardResponse.setScreeningStatus(callableStatement.getString("@pio_vc_amlstatus"));
			LOGGER.debug("Transaction Id: {} Allocate card response:{}", headers.get("transactionid"),
					allocateCardResponse.toString());
			if (allocateCardResponse.getErrorCode().equals(263)) {
				throw new DuplicateCardException(allocateCardResponse.getCardId(), 263,
						allocateCardResponse.getErrorText(), headers.get("transactionid"),
						allocateCardResponse.getCardNumber());
			} else if (!allocateCardResponse.getErrorCode().equals(0)) {
				throw new ElpasoException(allocateCardResponse.getErrorCode(), allocateCardResponse.getErrorText(),
						headers.get("transactionid"));
			}
			return allocateCardResponse;
		}
	}

	public static FircoScreeningResponse initiateScreening(Map<String, String> headers, CreateCardRequest walletReq,
			AllocateCardResponse allocateCardResponse) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		FircoScreeningRequest payload = new FircoScreeningRequest();
		ApplicationArea applicationArea = new ApplicationArea();
		applicationArea.setTransactionId(headers.get("transactionid"));
		applicationArea.setSenderId(headers.get("channelid").toUpperCase());
		applicationArea.setCountryOfOrigin(headers.get("countryoforigin"));
		applicationArea.setTransactionDateTime(headers.get("transactiondatetime"));
		applicationArea.setTransactionTimeZone(headers.get("transactiontimezone"));
		payload.setApplicationArea(applicationArea);
		DataArea dataArea = new DataArea();
		dataArea.setCustomerType(walletReq.getCustomerType());
		CustomerDetails customerDetails = new CustomerDetails();
		customerDetails.setFirstName(walletReq.getFirstName());
		customerDetails.setLastName(walletReq.getLastName());
		customerDetails.setName(walletReq.getFirstName() + " " + walletReq.getLastName());
		customerDetails.setGender(walletReq.getGender());
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setCountry(walletReq.getCountryOfResidence());
		contactDetails.setBirthDate(walletReq.getDob());
		contactDetails.setBirthPlace(walletReq.getBirthPlace());
		contactDetails.setCity(walletReq.getCity());
		Phone phone = new Phone();
		phone.setMobile(walletReq.getMobile());
		contactDetails.setPhone(phone);
		customerDetails.setContactDetails(contactDetails);
		List<Identification> identifications = new ArrayList<>();
		identifications.add(new Identification("NationalID", walletReq.getIdNumber()));
		customerDetails.setIdentification(identifications);
		dataArea.setCustomerDetails(customerDetails);
		payload.setDataArea(dataArea);
		String fircoInitiateUrl = System.getenv("FIRCO_INITIATE");
		URL url = new URL(fircoInitiateUrl);
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "application/json; utf-8");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("referenceNumber", allocateCardResponse.getCardId());
		connection.setRequestProperty("channelId", headers.get("channelid").toUpperCase());
		connection.setRequestProperty("countryOfOrigin", headers.get("countryoforigin"));
		connection.setRequestProperty("transactionDateTime", headers.get("transactiondatetime"));
		connection.setDoOutput(true);
		try (OutputStream os = connection.getOutputStream()) {
			String payloadStr = objectMapper.writeValueAsString(payload);
			LOGGER.info("Transaction Id: {} Firco initiate request:{}", headers.get("transactionid"), payloadStr);
			byte[] input = payloadStr.getBytes(StandardCharsets.UTF_8);
			os.write(input, 0, input.length);
		}
		if (100 <= connection.getResponseCode() && connection.getResponseCode() <= 399) {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("Transaction Id: {} Screen card firco - initiate screening response: {}",
						headers.get("transactionid"), response);
				FircoScreeningResponse screenCardResponse = objectMapper.readValue(response.toString(),
						FircoScreeningResponse.class);
				return screenCardResponse;
			}
		} else {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("Transaction Id: {} Screen card firco - initiate screening response: {}",
						headers.get("transactionid"), response);
				FircoScreeningResponse screenCardResponse = objectMapper.readValue(response.toString(),
						FircoScreeningResponse.class);
				return screenCardResponse;
			}
		}
	}

	public static CreateCardResponse updateCardStatus(Map<String, String> headers, CreateCardRequest request,
			AllocateCardResponse elpResponse, FircoScreeningResponse screenCardResponse) throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection
						.prepareCall("{call proc_setcardstatus_mbm(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_txnid#", Types.INTEGER);
			callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
			callableStatement.setInt("@pi_ti_txnsource", Integer.parseInt(headers.get("transactionsource")));
			if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CLEAN")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("22"));
			} else if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CONFCLEAN")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("20"));
			} else if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CONFBLOCK")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("19"));
			} else {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("21"));
			}
			callableStatement.setShort("@pi_ti_checkexpiryflag", Short.valueOf("0"));
			callableStatement.setShort("@pi_ti_reasonkey#", Short.valueOf("0"));
			callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
			callableStatement.setString("@pi_vc_clientIdentifier", headers.get("channelid"));
			callableStatement.setString("@pi_vc_cardno", "");
			callableStatement.setString("@pi_vc_reasontext", "");
			callableStatement.setString("@pi_c_expirydate", "");
			callableStatement.setString("@pi_vc_cardid", elpResponse.getCardId());
			callableStatement.setString("@pi_vc_MakerId", headers.get("channelid"));
			callableStatement.setString("@pi_vc_sourcetxnref",
					screenCardResponse.getApplicationArea().getCorrelationId());
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.execute();
			CreateCardResponse createCardResponse = new CreateCardResponse();
			createCardResponse.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
			createCardResponse.setErrorText(callableStatement.getString("@po_vc_errortext"));
			createCardResponse.setScreeningStatus(screenCardResponse.getResponseStatus().getStatusMessage());
			createCardResponse.setCardNumber(elpResponse.getCardNumber());
			createCardResponse.setIBAN("");
			createCardResponse.setCardId(elpResponse.getCardId());
			LOGGER.info("Transaction Id: {} Update card status response:{}", headers.get("transactionid"),
					createCardResponse);
			return createCardResponse;
		}
	}

}
