package com.fabmagnati.mbm.cardservices.v1Screening;

import com.fabmagnati.mbm.cardservices.v1Screening.response.ApplicationArea;
import com.fabmagnati.mbm.cardservices.v1Screening.response.DataArea;
import com.fabmagnati.mbm.cardservices.v1Screening.response.ResponseStatus;

public class FircoScreeningResponse {
	public ApplicationArea applicationArea;
	private DataArea dataArea;
	public String description;
	public String reasonCode;

	public String reasonDescription;

	public ResponseStatus responseStatus;

	public ApplicationArea getApplicationArea() {
		return applicationArea;
	}

	public DataArea getDataArea() {
		return dataArea;
	}

	public String getDescription() {
		return description;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public String getReasonDescription() {
		return reasonDescription;
	}

	public ResponseStatus getResponseStatus() {
		return responseStatus;
	}

	public void setApplicationArea(ApplicationArea applicationArea) {
		this.applicationArea = applicationArea;
	}

	public void setDataArea(DataArea dataArea) {
		this.dataArea = dataArea;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public void setReasonDescription(String reasonDescription) {
		this.reasonDescription = reasonDescription;
	}

	public void setResponseStatus(ResponseStatus responseStatus) {
		this.responseStatus = responseStatus;
	}

	@Override
	public String toString() {
		return "SCFResponse{" + "applicationArea=" + applicationArea + ", responseStatus=" + responseStatus
				+ ", description='" + description + '\'' + ", reasonCode='" + reasonCode + '\''
				+ ", reasonDescription='" + reasonDescription + '\'' + '}';
	}
}
