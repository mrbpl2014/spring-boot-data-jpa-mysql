package com.fabmagnati.mbm.cardservices.spend_limit;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SpendLimitValidationRequest {

    private int inqMode;

    private BigDecimal spendAmount;

    @NotNull(message = "value must not be null")
    @NotEmpty(message = "value must not be  empty")
    private String value;

}
