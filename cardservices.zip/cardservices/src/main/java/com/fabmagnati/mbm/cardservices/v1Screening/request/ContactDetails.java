package com.fabmagnati.mbm.cardservices.v1Screening.request;

public class ContactDetails {
	private String address1;
	private String address2;
	private String address3;
	private String address4;
	private String address5;
	private String birthDate;
	private String birthPlace;
	private String city;
	private String country;
	private String email;
	private Phone phone;
	private String state;
	private String visaExpiry;

	public String getAddress1() {
		return address1;
	}

	public String getAddress2() {
		return address2;
	}

	public String getAddress3() {
		return address3;
	}

	public String getAddress4() {
		return address4;
	}

	public String getAddress5() {
		return address5;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public String getCity() {
		return city;
	}

	public String getCountry() {
		return country;
	}

	public String getEmail() {
		return email;
	}

	public Phone getPhone() {
		return phone;
	}

	public String getState() {
		return state;
	}

	public String getVisaExpiry() {
		return visaExpiry;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPhone(Phone phone) {
		this.phone = phone;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setVisaExpiry(String visaExpiry) {
		this.visaExpiry = visaExpiry;
	}
}
