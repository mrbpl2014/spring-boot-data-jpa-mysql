package com.fabmagnati.mbm.cardservices.v1Screening;

public class V1ScreeningService {

}
