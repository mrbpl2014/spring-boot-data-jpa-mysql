package com.fabmagnati.mbm.cardservices.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fabmagnati.mbm.cardservices.debitAdvise.DebitAdviseRequest;
import com.fabmagnati.mbm.cardservices.debitAdvise.DebitAdviseResponse;
import com.fabmagnati.mbm.cardservices.debitAdvise.DebitAdviseService;
import com.fabmagnati.mbm.cardservices.balace_enquiry.BalanceEnquiryRequest;
import com.fabmagnati.mbm.cardservices.balace_enquiry.BalanceEnquiryResponse;
import com.fabmagnati.mbm.cardservices.card_replacement.CardReplacementRequest;
import com.fabmagnati.mbm.cardservices.card_replacement.CardReplacementResponse;
import com.fabmagnati.mbm.cardservices.card_status_update.UpdateCardStatusRequest;
import com.fabmagnati.mbm.cardservices.card_status_update.UpdateCardStatusResponse;
import com.fabmagnati.mbm.cardservices.createCard.CreateCardRequest;
import com.fabmagnati.mbm.cardservices.createCard.CreateCardResponse;
import com.fabmagnati.mbm.cardservices.createCard.CreateCardService;
import com.fabmagnati.mbm.cardservices.update_customer.UpdateCustomerDataRequest;
import com.fabmagnati.mbm.cardservices.update_customer.UpdateCustomerDataResponse;
import com.fabmagnati.mbm.cardservices.load_limit_validation.LoadLimitValidationRequest;
import com.fabmagnati.mbm.cardservices.load_limit_validation.LoadLimitValidationResponse;
import com.fabmagnati.mbm.cardservices.notify_card_transactions.NotifyCardTransactionRequest;
import com.fabmagnati.mbm.cardservices.notify_card_transactions.NotifyCardTransactionResponse;
import com.fabmagnati.mbm.cardservices.pos_limit_inquiry.POSLimitInquiryRequest;
import com.fabmagnati.mbm.cardservices.pos_limit_inquiry.POSLimitInquiryResponse;
import com.fabmagnati.mbm.cardservices.pos_limit_update.POSLimitUpdateRequest;
import com.fabmagnati.mbm.cardservices.pos_limit_update.POSLimitUpdateResponse;
import com.fabmagnati.mbm.cardservices.spend_limit.SpendLimitValidationRequest;
import com.fabmagnati.mbm.cardservices.spend_limit.SpendLimitValidationResponse;
import com.fabmagnati.mbm.cardservices.debit_transaction.DebitTxnRequest;
import com.fabmagnati.mbm.cardservices.debit_transaction.DebitTxnResponse;
import com.fabmagnati.mbm.cardservices.transaction_history.TransactionHistoryRequest;
import com.fabmagnati.mbm.cardservices.transaction_history.TransactionHistoryResponse;
import com.fabmagnati.mbm.cardservices.balace_enquiry.BalanceEnquiryService;
import com.fabmagnati.mbm.cardservices.card_replacement.CardReplacementService;
import com.fabmagnati.mbm.cardservices.card_status_update.CardStatusUpdateService;
import com.fabmagnati.mbm.cardservices.update_customer.CustomerService;
import com.fabmagnati.mbm.cardservices.load_limit_validation.LoadLimitValidation;
import com.fabmagnati.mbm.cardservices.notify_card_transactions.NotifyCardTransactionService;
import com.fabmagnati.mbm.cardservices.pos_limit_update.POSLimitUpdateService;
import com.fabmagnati.mbm.cardservices.pos_limit_inquiry.PosLimitInquiryService;
import com.fabmagnati.mbm.cardservices.spend_limit.SpendLimitValidation;
import com.fabmagnati.mbm.cardservices.debit_transaction.DebitTxnService;
import com.fabmagnati.mbm.cardservices.get_status.GetStatusRequest;
import com.fabmagnati.mbm.cardservices.get_status.GetStatusResponse;
import com.fabmagnati.mbm.cardservices.get_status.GetStatusService;
import com.fabmagnati.mbm.cardservices.transaction_history.TransactionHistoryService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

@RestController
public class CardRestController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CardRestController.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Autowired
    BalanceEnquiryService balanceEnquiryService;

    @Autowired
    POSLimitUpdateService posLimitUpdateService;

    @Autowired
    TransactionHistoryService transactionHistoryService;

    @Autowired
    CardReplacementService cardReplacementService;

    @Autowired
    LoadLimitValidation loadLimitValidation;

    @Autowired
    NotifyCardTransactionService notifyCardTransactionService;

    @Autowired
    CustomerService customerService;

    @Autowired
    PosLimitInquiryService posLimitInquiryService;

    @Autowired
    SpendLimitValidation spendLimitValidation;

    @Autowired
    DebitTxnService debitTxnService;

    @Autowired
    CardStatusUpdateService cardStatusUpdateService;

    @Autowired
    GetStatusService getStatusService;

    @PostMapping("/createCard")
    CreateCardResponse createCard(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody CreateCardRequest createCardRequest) throws SQLException, IOException {
        CreateCardResponse response = CreateCardService.processRequest(headers, createCardRequest);
        LOGGER.info("Transaction id: {} Response data: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));
        return response;
    }

    @PostMapping("/getBalance")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public BalanceEnquiryResponse balanceEnquiry(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody BalanceEnquiryRequest request) throws SQLException, JsonProcessingException {
        BalanceEnquiryResponse response = balanceEnquiryService.balanceEnquiry(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;

    }

    @PostMapping("/cardReplacement")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public CardReplacementResponse cardReplacement(@RequestHeader Map<String, String> headers,
            @RequestBody CardReplacementRequest request) throws SQLException, JsonProcessingException {
        CardReplacementResponse response = cardReplacementService.cardReplacement(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/debitAdvise")
    DebitAdviseResponse debitAdvise(@RequestHeader Map<String, String> headers, @RequestBody DebitAdviseRequest request)
            throws SQLException {
        DebitAdviseResponse response = DebitAdviseService.processTransaction(headers, request);
        return response;
    }

    @PostMapping("/debitTransaction")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public DebitTxnResponse debitTransaction(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody DebitTxnRequest request) throws SQLException, JsonProcessingException {
        DebitTxnResponse response = debitTxnService.debitTransaction(headers, request);
        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));
        return response;

    }

    @PostMapping("/getLoadLimits")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public LoadLimitValidationResponse loadLimitValidation(@RequestHeader Map<String, String> headers,
            @RequestBody LoadLimitValidationRequest request) throws SQLException, JsonProcessingException {

        LoadLimitValidationResponse response = loadLimitValidation.loadLimitValidation(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/notifyCardTxns")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public NotifyCardTransactionResponse notifyCardTransactions(@RequestHeader Map<String, String> headers,
            @RequestBody NotifyCardTransactionRequest request) throws JsonProcessingException {
        NotifyCardTransactionResponse response = notifyCardTransactionService.notifyCardTransactions(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/getPosLimits")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public POSLimitInquiryResponse posLimitInquiry(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody POSLimitInquiryRequest request) throws SQLException, JsonProcessingException {
        POSLimitInquiryResponse response = posLimitInquiryService.inquirePOSLimit(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/getSpendLimits")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public SpendLimitValidationResponse spendLimitValidation(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody SpendLimitValidationRequest request) throws SQLException, JsonProcessingException {
        SpendLimitValidationResponse response = spendLimitValidation.validateSpendLimit(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;

    }

    @PostMapping("/getTransactionHistory")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public TransactionHistoryResponse transactionHistory(@RequestHeader Map<String, String> headers,
            @Valid @RequestBody TransactionHistoryRequest request) throws SQLException, JsonProcessingException {
        TransactionHistoryResponse response = transactionHistoryService.getTransactionHistory(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/updateCustomerdata")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public UpdateCustomerDataResponse updateCustomerData(@RequestHeader Map<String, String> headers,
            @RequestBody UpdateCustomerDataRequest request) throws SQLException, JsonProcessingException {
        UpdateCustomerDataResponse response = customerService.updateCustomerData(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/updatePosLimits")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public POSLimitUpdateResponse updatePOSLimits(@RequestHeader Map<String, String> headers,
            @RequestBody POSLimitUpdateRequest request) throws SQLException, JsonProcessingException {
        POSLimitUpdateResponse response = posLimitUpdateService.posLimitUpdate(headers, request);

        LOGGER.info("TRANSACTION ID: {} RESPONSE DATA: {}", headers.get("transactionid"),
                OBJECT_MAPPER.writeValueAsString(response));

        return response;
    }

    @PostMapping("/updateCardStatus")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public UpdateCardStatusResponse updateCardSatus(@RequestHeader Map<String, String> headers,
            @RequestBody UpdateCardStatusRequest request) throws SQLException, JsonProcessingException {

        UpdateCardStatusResponse response = cardStatusUpdateService.updateCardStatus(headers, request);

        return response;
    }

    @PostMapping("/getStatus")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "Content-Type", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "channelId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "countryOfOrigin", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionId", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionTimeZone", dataTypeClass = String.class, paramType = "header"),
        @ApiImplicitParam(name = "transactionDateTime", dataTypeClass = String.class, paramType = "header")})
    public GetStatusResponse getStatus(@RequestHeader Map<String, String> headers,
            @RequestBody GetStatusRequest request) throws SQLException, JsonProcessingException {

        GetStatusResponse response = getStatusService.getStatus(headers, request);

        return response;
    }

}
