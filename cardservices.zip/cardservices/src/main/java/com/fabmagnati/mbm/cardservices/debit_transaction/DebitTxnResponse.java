package com.fabmagnati.mbm.cardservices.debit_transaction;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@ToString
public class DebitTxnResponse {
    private BigDecimal availableBalance;
    private String cardId;
    private BigDecimal currentBalance;
    private String errorCode;
    private String errorText;
    private String status;
    private String txnId;

}
