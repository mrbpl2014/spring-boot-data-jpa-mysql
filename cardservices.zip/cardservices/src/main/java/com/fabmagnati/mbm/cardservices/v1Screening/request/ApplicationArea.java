package com.fabmagnati.mbm.cardservices.v1Screening.request;

public class ApplicationArea {
	private String countryOfOrigin;
	private String senderId;
	private String senderReferenceID;
	private String transactionDateTime;
	private String transactionId;
	private String transactionTimeZone;

	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public String getSenderId() {
		return senderId;
	}

	public String getSenderReferenceID() {
		return senderReferenceID;
	}

	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getTransactionTimeZone() {
		return transactionTimeZone;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public void setSenderReferenceID(String senderReferenceID) {
		this.senderReferenceID = senderReferenceID;
	}

	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setTransactionTimeZone(String transactionTimeZone) {
		this.transactionTimeZone = transactionTimeZone;
	}
}
