package com.fabmagnati.mbm.cardservices.checkScreeningStatus;

public class CheckScreeningStatusResponse {
	private String errorCode;
	private String errorText;
	private String screeningStatus;

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public String getScreeningStatus() {
		return screeningStatus;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public void setScreeningStatus(String screeningStatus) {
		this.screeningStatus = screeningStatus;
	}
}
