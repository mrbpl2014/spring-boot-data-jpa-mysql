package com.fabmagnati.mbm.cardservices.v1Screening;

import com.fabmagnati.mbm.cardservices.v1Screening.request.ApplicationArea;
import com.fabmagnati.mbm.cardservices.v1Screening.request.DataArea;

public class FircoScreeningRequest {
	public ApplicationArea applicationArea;
	public DataArea dataArea;

	public ApplicationArea getApplicationArea() {
		return applicationArea;
	}

	public DataArea getDataArea() {
		return dataArea;
	}

	public void setApplicationArea(ApplicationArea applicationArea) {
		this.applicationArea = applicationArea;
	}

	public void setDataArea(DataArea dataArea) {
		this.dataArea = dataArea;
	}
}
