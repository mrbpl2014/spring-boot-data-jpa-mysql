package com.fabmagnati.mbm.cardservices.spend_limit;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SpendLimitValidationResponse {

    private String errorCode;
    private String errorText;
    private BigDecimal availableBalance;
    private BigDecimal currentBalance;
    private String cardId;
    private String iban;
    private String cardStatus;
    private String firstName;
    private String lastName;
    private String middleName;
    private BigDecimal possibleSpendAmount;
    private String productDescription;
    private int productType;

}
