package com.fabmagnati.mbm.cardservices.exception;

import lombok.Data;

@Data
public class ElpasoError {

    private String errorCode;
    private String errorText;
}