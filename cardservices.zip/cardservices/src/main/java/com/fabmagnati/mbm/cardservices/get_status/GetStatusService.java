/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.get_status;

import com.fabmagnati.mbm.cardservices.card_status_update.CardStatusUpdateService;
import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class GetStatusService {

    private static final Logger logger = LoggerFactory.getLogger(CardStatusUpdateService.class);

    public GetStatusResponse getStatus(Map<String, String> headers, GetStatusRequest request)
            throws SQLException {
        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall(
                "{call proc_get_cardscreening_MBM(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {

            callableStatement.registerOutParameter("@pio_vc_cardid", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_salutation", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_firstnameenglish", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_lastnameenglish", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_gender", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_enqrefno", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_address1", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_address2", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_address3", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_address4", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_city", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_countryofresidence", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_emirates", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_birthPlace", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_dob", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_idtype", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_id#", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_c_custtype", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_postalcode", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_countrycode", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_email", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_mobile", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_occupation", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_version", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_cardStatus", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_cardExpiry", Types.VARCHAR);

            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifer", headers.get("clientidentifier"));
            callableStatement.setString("@pio_vc_cardid", request.getCardId());
            callableStatement.execute();

            GetStatusResponse response = new GetStatusResponse();
            response.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
            response.setErrorText(callableStatement.getString("@po_vc_errortext"));
            response.setScreeningStatus(callableStatement.getString("@po_vc_cardStatus"));

            logger.debug("TRANSACTION ID: {} UPDATE CARD STATUS RESPONSE:{}", headers.get("transactionid"), response);

            return response;
        }
    }
}
