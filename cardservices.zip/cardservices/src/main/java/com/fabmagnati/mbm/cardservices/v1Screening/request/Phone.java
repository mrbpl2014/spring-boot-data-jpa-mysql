package com.fabmagnati.mbm.cardservices.v1Screening.request;

public class Phone {
	private String mobile;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
}
