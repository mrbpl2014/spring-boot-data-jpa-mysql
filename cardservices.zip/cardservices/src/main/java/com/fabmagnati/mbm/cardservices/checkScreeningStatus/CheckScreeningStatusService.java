package com.fabmagnati.mbm.cardservices.checkScreeningStatus;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import com.fabmagnati.mbm.cardservices.v1Screening.FircoScreeningRequest;
import com.fabmagnati.mbm.cardservices.v1Screening.FircoScreeningResponse;
import com.fabmagnati.mbm.cardservices.v1Screening.request.ApplicationArea;
import com.fabmagnati.mbm.cardservices.v1Screening.request.ContactDetails;
import com.fabmagnati.mbm.cardservices.v1Screening.request.CustomerDetails;
import com.fabmagnati.mbm.cardservices.v1Screening.request.DataArea;
import com.fabmagnati.mbm.cardservices.v1Screening.request.Identification;
import com.fabmagnati.mbm.cardservices.v1Screening.request.Phone;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CheckScreeningStatusService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CheckScreeningStatusService.class);
	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	public static CheckScreeningStatusResponse processRequest(Map<String, String> headers,
			CheckScreeningStatusRequest checkScreeningStatusRequest) throws SQLException, IOException {
		FircoScreeningRequest screenCardRequest = getCustomerDetails(headers, checkScreeningStatusRequest);
		FircoScreeningResponse screenCardResponse = checkScreeningStatus(headers, checkScreeningStatusRequest,
				screenCardRequest);
		CheckScreeningStatusResponse checkScreeningStatusResponse = updateCardStatus(headers,
				checkScreeningStatusRequest, screenCardResponse);
		return checkScreeningStatusResponse;
	}

	public static FircoScreeningRequest getCustomerDetails(Map<String, String> headers,
			CheckScreeningStatusRequest checkScreeningStatusRequest) throws SQLException, IOException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection.prepareCall(
						"{call proc_get_cardscreeninginquiry_wallet_v2(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@pio_vc_cardid", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_salutation", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_firstnameenglish", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_lastnameenglish", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_gender", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_enqrefno", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_address1", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_address2", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_address3", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_address4", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_city", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_countryofresidence", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_emirates", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_birthPlace", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_dob", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_idtype", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_id#", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_c_custtype", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_postalcode", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_countrycode", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_email", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_mobile", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_occupation", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);
			callableStatement.registerOutParameter("@po_vc_version", Types.VARCHAR);
                        callableStatement.registerOutParameter("@po_vc_cardStatus", Types.VARCHAR);
                        callableStatement.registerOutParameter("@po_vc_cardExpiry", Types.VARCHAR);
			callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.setString("@pi_vc_clientIdentifer", headers.get("channelid"));
			callableStatement.setString("@pio_vc_cardid", checkScreeningStatusRequest.getCorrelationId());
			callableStatement.execute();
			if (!(callableStatement.getInt("@po_i_errorcode") == 0)) {
				throw new ElpasoException(callableStatement.getInt("@po_i_errorcode"),
						callableStatement.getString("@po_vc_errortext"), headers.get("transactionid"));
			}
			FircoScreeningRequest payload = new FircoScreeningRequest();
			ApplicationArea applicationArea = new ApplicationArea();
			applicationArea.setTransactionId(headers.get("transactionid"));
			applicationArea.setSenderId(headers.get("channelid").toUpperCase());
			applicationArea.setCountryOfOrigin(headers.get("countryoforigin"));
			applicationArea.setTransactionDateTime(headers.get("transactiondatetime"));
			applicationArea.setTransactionTimeZone(headers.get("transactiontimezone"));
			payload.setApplicationArea(applicationArea);
			DataArea dataArea = new DataArea();
			dataArea.setCustomerType(callableStatement.getString("@po_c_custtype"));
			dataArea.setEnquiryRefNumber(callableStatement.getString("@po_vc_enqrefno"));
			CustomerDetails customerDetails = new CustomerDetails();
			customerDetails.setFirstName(callableStatement.getString("@po_vc_firstnameenglish"));
			customerDetails.setLastName(callableStatement.getString("@po_vc_lastnameenglish"));
			customerDetails.setName(callableStatement.getString("@po_vc_firstnameenglish") + " "
					+ callableStatement.getString("@po_vc_lastnameenglish"));
			customerDetails.setGender(callableStatement.getString("@po_vc_gender"));
			ContactDetails contactDetails = new ContactDetails();
			contactDetails.setCountry(callableStatement.getString("@po_vc_countryofresidence"));
			contactDetails.setBirthPlace(callableStatement.getString("@po_vc_birthPlace"));
			contactDetails.setBirthDate(callableStatement.getString("@po_vc_dob"));
			contactDetails.setCity(callableStatement.getString("@po_vc_city"));
			Phone phone = new Phone();
			phone.setMobile(callableStatement.getString("@po_vc_mobile"));
			contactDetails.setPhone(phone);
			customerDetails.setContactDetails(contactDetails);
			List<Identification> identifications = new ArrayList<>();
			identifications.add(new Identification("NationalID", callableStatement.getString("@po_vc_id#")));
			customerDetails.setIdentification(identifications);
			dataArea.setCustomerDetails(customerDetails);
			payload.setDataArea(dataArea);			
			return payload;
		}
	}

	public static CheckScreeningStatusResponse updateCardStatus(Map<String, String> headers,
			CheckScreeningStatusRequest checkScreeningStatusRequest, FircoScreeningResponse screenCardResponse)
			throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection.prepareCall(
						"{call proc_setcardstatus_mbm(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_txnid#", Types.INTEGER);
			callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
			callableStatement.setInt("@pi_ti_txnsource", Integer.parseInt(headers.get("transactionsource")));
			if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CLEAN")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("22"));
			} else if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CONFCLEAN")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("20"));
			} else if (screenCardResponse.getResponseStatus().getStatusMessage().equalsIgnoreCase("CONFBLOCK")) {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("19"));
			} else {
				callableStatement.setShort("@pi_ti_newstatus", Short.valueOf("21"));
			}
			callableStatement.setShort("@pi_ti_checkexpiryflag", Short.valueOf("0"));
			callableStatement.setShort("@pi_ti_reasonkey#", Short.valueOf("0"));
			callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
			callableStatement.setString("@pi_vc_clientIdentifier", headers.get("channelid"));
			callableStatement.setString("@pi_vc_cardno", "");
			callableStatement.setString("@pi_vc_reasontext", "");
			callableStatement.setString("@pi_c_expirydate", "");
			callableStatement.setString("@pi_vc_cardid", checkScreeningStatusRequest.getCorrelationId());
			callableStatement.setString("@pi_vc_MakerId", headers.get("channelid"));
			callableStatement.setString("@pi_vc_sourcetxnref",
					screenCardResponse.getApplicationArea().getCorrelationId());
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.execute();
			CheckScreeningStatusResponse checkScreeningStatusResponse = new CheckScreeningStatusResponse();
			checkScreeningStatusResponse.setScreeningStatus(screenCardResponse.getResponseStatus().getStatusMessage());
			checkScreeningStatusResponse.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
			checkScreeningStatusResponse.setErrorText(callableStatement.getString("@po_vc_errortext"));
			return checkScreeningStatusResponse;
		}
	}

	public static FircoScreeningResponse checkScreeningStatus(Map<String, String> headers,
			CheckScreeningStatusRequest checkScreeningStatusRequest, FircoScreeningRequest payload)
			throws IOException, SQLException {
		String payloadStr = OBJECT_MAPPER.writeValueAsString(payload);		
		LOGGER.info("Firco enquiry request payload: {}", payloadStr);
		String fircoEnquiryUrl = System.getenv("FIRCO_ENQUIRY");
		URL url = new URL(fircoEnquiryUrl);
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "application/json; utf-8");
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("referenceNumber", checkScreeningStatusRequest.getCorrelationId());
		connection.setRequestProperty("channelId", headers.get("channelid").toUpperCase());
		connection.setRequestProperty("countryOfOrigin", headers.get("countryoforigin"));
		connection.setRequestProperty("transactionDateTime", headers.get("transactiondatetime"));
		connection.setDoOutput(true);
		try (OutputStream os = connection.getOutputStream()) {
			byte[] input = payloadStr.getBytes(StandardCharsets.UTF_8);
			os.write(input, 0, input.length);
		}
		LOGGER.info("Firco enquiry response code: {}", connection.getResponseCode());
		if (100 <= connection.getResponseCode() && connection.getResponseCode() <= 399) {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("Transaction Id: {} Screening enquiry response: {}", headers.get("transactionid"),
						response);
				FircoScreeningResponse screenCardResponse = OBJECT_MAPPER.readValue(response.toString(),
						FircoScreeningResponse.class);
				return screenCardResponse;
			}
		} else {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("Transaction Id: {} Screening enquiry response: {}", headers.get("transactionid"),
						response);
				FircoScreeningResponse screenCardResponse = OBJECT_MAPPER.readValue(response.toString(),
						FircoScreeningResponse.class);
				return screenCardResponse;
			}
		}
	}

}
