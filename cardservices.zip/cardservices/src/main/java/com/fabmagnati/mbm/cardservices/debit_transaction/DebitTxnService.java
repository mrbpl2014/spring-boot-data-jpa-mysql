package com.fabmagnati.mbm.cardservices.debit_transaction;


import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import com.fabmagnati.mbm.cardservices.debit_transaction.DebitTxnRequest;
import com.fabmagnati.mbm.cardservices.debit_transaction.DebitTxnResponse;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class DebitTxnService {

    public DebitTxnResponse debitTransaction(Map<String, String> headers, DebitTxnRequest request)
            throws SQLException {
        try (Connection connection = Datasource.getConnection(); CallableStatement callableStatement = connection.prepareCall(
                "{call Proc_debit_txn_wallet_v3(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
            callableStatement.registerOutParameter("@pio_vc_cardid", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_cardcurrcode", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_avlbalamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_curbalamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_i_txnid", Types.INTEGER);
            callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);
            callableStatement.setInt("@pi_ti_txnsource", Integer.parseInt(headers.get("transactionsource")));
            callableStatement.setShort("@pi_si_txntype", request.getTransactionType());
            callableStatement.setShort("@pi_si_feetype#", request.getFeeType());
            callableStatement.setString("@pi_vc_clientIdentifer", headers.get("clientidentifier"));
            callableStatement.setString("@pio_vc_cardid", request.getCardId());
            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setString("@pi_vc_sourcemakerid", request.getTerminalId());
            callableStatement.setString("@pi_vc_desc2", request.getMerchantName());
            callableStatement.setString("@pi_vc_merchantlocation", request.getMerchantLocation());
            callableStatement.setString("@pi_vc_sourceposid", request.getMerchantId());
            callableStatement.setString("@pi_vc_retrievalrefno", request.getRrn());
            callableStatement.setString("@pi_vc_txncurrcode", request.getTransactionCurrency());
            callableStatement.setString("@pi_vc_billcurrcode", request.getEquivalentCurrency());
            callableStatement.setString("@pi_vc_authcode", request.getAuthorizationCode());
            callableStatement.setString("@pi_vc_desc1", request.getRemarks());
            callableStatement.setString("@pi_vc_feedesc1", request.getFeeDescription());
            callableStatement.setString("@pi_vc_txnidentifier", headers.get("transactionid"));
            callableStatement.setString("@pi_vc_sourcetxnref", request.getSourceTxnReferenceNo());
            callableStatement.setString("@pi_vc_onlhostrefno", request.getOnlineHostReferenceNo());
            callableStatement.setString("@pi_vc_txnrefno", request.getTxnReferenceNo());
            try {
                callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                        Timestamp.valueOf(headers.get("transactiondatetime")));
                callableStatement.setTimestamp("@pi_dt_txndatetime",
                        Timestamp.valueOf(headers.get("transactiondatetime")));
            } catch (Exception e) {
                throw new ElpasoException(294, "Technical Error Occured, please contact Magnati support",
                        headers.get("transactionid"));
            }
            callableStatement.setBigDecimal("@pi_nm_feeamount", request.getFeeAmount());
            callableStatement.setBigDecimal("@pi_nm_txnrate", request.getTransactionRate());
            callableStatement.setBigDecimal("@pi_nm_txnamount", request.getTransactionAmount());
            callableStatement.setBigDecimal("@pi_nm_billamount", request.getEquivalentAmount());
            callableStatement.execute();
            if (!(callableStatement.getInt("@po_i_errorcode") == 0)) {
                throw new ElpasoException(callableStatement.getInt("@po_i_errorcode"),
                        callableStatement.getString("@po_vc_errortext"), headers.get("transactionid"));
            }
            DebitTxnResponse debitTxnResponse = new DebitTxnResponse();
            debitTxnResponse.setStatus("SUCCESS");
            debitTxnResponse.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorcode")));
            debitTxnResponse.setErrorText(callableStatement.getString("@po_vc_errortext"));
            debitTxnResponse.setAvailableBalance(callableStatement.getBigDecimal("@po_nm_avlbalamount"));
            debitTxnResponse.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_curbalamount"));
            debitTxnResponse.setCardId(callableStatement.getString("@pio_vc_cardid"));
            debitTxnResponse.setTxnId(String.valueOf(callableStatement.getInt("@po_i_txnid")));
            return debitTxnResponse;
        }
    }

}
