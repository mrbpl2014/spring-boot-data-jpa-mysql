package com.fabmagnati.mbm.cardservices.debitAdvise;

import java.math.BigDecimal;

public class DebitAdviseRequest {
	private String cardId;
	private String transactionId;
	private String originalTransactionId;
	private Short reversalFlag;
	private Short txnSource;
	private String desc;
	private Short feeType;
	private BigDecimal feeAmount;
	private BigDecimal txnAmount;
	private BigDecimal billAmount;
	private String txnCurrCode;
	private String billCurrCode;
	private BigDecimal txnRate;
	private String retrivalRefNo;
	private Short transactionType;

	public BigDecimal getBillAmount() {
		return billAmount;
	}

	public String getBillCurrCode() {
		return billCurrCode;
	}

	public String getCardId() {
		return cardId;
	}

	public String getDesc() {
		return desc;
	}

	public BigDecimal getFeeAmount() {
		return feeAmount;
	}

	public Short getFeeType() {
		return feeType;
	}

	public String getOriginalTransactionId() {
		return originalTransactionId;
	}

	public String getRetrivalRefNo() {
		return retrivalRefNo;
	}

	public Short getReversalFlag() {
		return reversalFlag;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public Short getTransactionType() {
		return transactionType;
	}

	public BigDecimal getTxnAmount() {
		return txnAmount;
	}

	public String getTxnCurrCode() {
		return txnCurrCode;
	}

	public BigDecimal getTxnRate() {
		return txnRate;
	}

	public Short getTxnSource() {
		return txnSource;
	}

	public void setBillAmount(BigDecimal billAmount) {
		this.billAmount = billAmount;
	}

	public void setBillCurrCode(String billCurrCode) {
		this.billCurrCode = billCurrCode;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public void setFeeAmount(BigDecimal feeAmount) {
		this.feeAmount = feeAmount;
	}

	public void setFeeType(Short feeType) {
		this.feeType = feeType;
	}

	public void setOriginalTransactionId(String originalTransactionId) {
		this.originalTransactionId = originalTransactionId;
	}

	public void setRetrivalRefNo(String retrivalRefNo) {
		this.retrivalRefNo = retrivalRefNo;
	}

	public void setReversalFlag(Short reversalFlag) {
		this.reversalFlag = reversalFlag;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setTransactionType(Short transactionType) {
		this.transactionType = transactionType;
	}

	public void setTxnAmount(BigDecimal txnAmount) {
		this.txnAmount = txnAmount;
	}

	public void setTxnCurrCode(String txnCurrCode) {
		this.txnCurrCode = txnCurrCode;
	}

	public void setTxnRate(BigDecimal txnRate) {
		this.txnRate = txnRate;
	}

	public void setTxnSource(Short txnSource) {
		this.txnSource = txnSource;
	}
}
