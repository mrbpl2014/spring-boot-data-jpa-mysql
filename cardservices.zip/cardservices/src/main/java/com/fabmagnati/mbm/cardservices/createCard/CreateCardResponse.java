package com.fabmagnati.mbm.cardservices.createCard;

public class CreateCardResponse {
	private String errorCode;
	private String errorText;
	private String screeningStatus;
	private String cardNumber;
	private String IBAN;
	private String cardId;

	public CreateCardResponse() {
	}

	public String getCardId() {
		return cardId;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public String getIBAN() {
		return IBAN;
	}

	public String getScreeningStatus() {
		return screeningStatus;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public void setIBAN(String IBAN) {
		this.IBAN = IBAN;
	}

	public void setScreeningStatus(String screeningStatus) {
		this.screeningStatus = screeningStatus;
	}

	@Override
	public String toString() {
		return "CreateCardRes{" + "errorCode=" + errorCode + ", errorText='" + errorText + '\'' + ", screeningStatus='"
				+ screeningStatus + '\'' + ", cardNumber='" + cardNumber + '\'' + ", IBAN='" + IBAN + '\''
				+ ", cardId='" + cardId + '\'' + '}';
	}
}
