package com.fabmagnati.mbm.cardservices.exception;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CommanExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(CommanExceptionHandler.class);

    @ExceptionHandler({ Exception.class })
    public ResponseEntity<Object> handleAll(final Exception ex, final WebRequest request) {
        log.error(request.getHeader("transactionid"), ex.getMessage(), ex);
        final ApiError apiError = new ApiError(String.valueOf(294),
                "Technical Error Occured, please contact Magnati support");
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), HttpStatus.OK);
    }

    @ExceptionHandler(DuplicateCardException.class)
    public ResponseEntity<Object> handleDuplicateCardException(DuplicateCardException exception) {
        log.error(exception.getTransactionId(), exception.getMessage(), exception);
        DuplicateCardError duplicateCardError = new DuplicateCardError();
        duplicateCardError.setErrorCode(String.valueOf(exception.getErrorCode()));
        duplicateCardError.setErrorText(exception.getErrorText());
        duplicateCardError.setCardId(exception.getCardId());
        return new ResponseEntity<Object>(duplicateCardError, HttpStatus.OK);
    }


    @ExceptionHandler(ElpasoException.class)
    public ResponseEntity<Object> handleElpasoException(ElpasoException exception) {
        log.error(exception.getTransactionId(), exception.getMessage(), exception);
        ElpasoError elpasoError = new ElpasoError();
        elpasoError.setErrorCode(String.valueOf(exception.getErrorCode()));
        elpasoError.setErrorText(exception.getErrorDesc());
        return new ResponseEntity<>(elpasoError, HttpStatus.OK);
    }


    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error(request.getHeader("transactionid"), ex.getMessage(), ex);
        final ApiError apiError = new ApiError(String.valueOf(212), "Mandatory input fields can not be empty");
        return new ResponseEntity<>(apiError, HttpStatus.OK);
    }


}
