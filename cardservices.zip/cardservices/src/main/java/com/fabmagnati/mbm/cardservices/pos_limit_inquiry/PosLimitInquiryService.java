package com.fabmagnati.mbm.cardservices.pos_limit_inquiry;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.pos_limit_inquiry.POSLimitInquiryRequest;
import com.fabmagnati.mbm.cardservices.pos_limit_inquiry.POSLimitInquiryResponse;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class PosLimitInquiryService {

    public POSLimitInquiryResponse inquirePOSLimit(Map<String, String> headers, POSLimitInquiryRequest request)
            throws SQLException {

        try (Connection connection = Datasource.getConnection();
             CallableStatement callableStatement = connection.prepareCall(
                     "{call proc_get_PosLimitInquiry_wallet(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {
            callableStatement.registerOutParameter("@po_vc_cardId", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_iban", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_maxPosSingleTxnLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_dailyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_monthlyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_productDescription", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_productType", Types.INTEGER);
            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errorText", Types.VARCHAR);
            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
            callableStatement.setShort("@pi_ti_inquiryMode", (short) request.getInqMode());
            callableStatement.setString("@pi_vc_value", request.getValue());

            callableStatement.execute();

            POSLimitInquiryResponse response = new POSLimitInquiryResponse();

            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));
            response.setMaxpossingletxnlimit(callableStatement.getBigDecimal("@po_nm_maxPosSingleTxnLimit"));
            response.setDailyPosLimit(callableStatement.getBigDecimal("@po_nm_dailyPosLimit"));
            response.setMonthlyPosLimit(callableStatement.getBigDecimal("@po_nm_monthlyPosLimit"));
            response.setProductDescription(callableStatement.getString("@po_vc_productDescription"));
            response.setProductType(callableStatement.getInt("@po_i_productType"));
            response.setCardId(callableStatement.getString("@po_vc_cardId"));
            response.setIban(callableStatement.getString("@po_vc_iban"));

            return response;
        }
    }

}
