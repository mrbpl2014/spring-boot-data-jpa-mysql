package com.fabmagnati.mbm.cardservices.createCard;

public class CreateCardRequest {

	private Short arrowRegistered;
	private String customerType;
	private Short documentsVerified;
	private Integer prefixTitle;
	private String firstName;
	private String middleName;
	private String lastName;
	private String embossedName;
	private String dob;
	private String nationality;
	private String countryOfResidence;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String city;
	private String countryCode;
	private String postalCode;
	private String mobile;
	private String email;
	private String occupation;
	private Short idType;
	private String idNumber;
	private String idExpiryDate;
	private String idIssueCountryId;
	private String cardId;
	private String walletId;
	private String gender;
	private String cardType;
	private Integer productType;
	private String pcif;
	private String visaExpiryDate;
	private String birthPlace;

	private Short emirates;
	private String companyName;

	public String getAddressLine1() {
		return addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public Short getArrowRegistered() {
		return arrowRegistered;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public String getCardId() {
		return cardId;
	}

	public String getCardType() {
		return cardType;
	}

	public String getCity() {
		return city;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public String getCountryOfResidence() {
		return countryOfResidence;
	}

	public String getCustomerType() {
		return customerType;
	}

	public String getDob() {
		return dob;
	}

	public Short getDocumentsVerified() {
		return documentsVerified;
	}

	public String getEmail() {
		return email;
	}

	public String getEmbossedName() {
		return embossedName;
	}

	public Short getEmirates() {
		return emirates;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getGender() {
		return gender;
	}

	public String getIdExpiryDate() {
		return idExpiryDate;
	}

	public String getIdIssueCountryId() {
		return idIssueCountryId;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public Short getIdType() {
		return idType;
	}

	public String getLastName() {
		return lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getMobile() {
		return mobile;
	}

	public String getNationality() {
		return nationality;
	}

	public String getOccupation() {
		return occupation;
	}

	public String getPcif() {
		return pcif;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public Integer getPrefixTitle() {
		return prefixTitle;
	}

	public Integer getProductType() {
		return productType;
	}

	public String getVisaExpiryDate() {
		return visaExpiryDate;
	}

	public String getWalletId() {
		return walletId;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public void setArrowRegistered(Short arrowRegistered) {
		this.arrowRegistered = arrowRegistered;
	}

	public void setBirthPlace(String birthPlace) {
		this.birthPlace = birthPlace;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setCountryOfResidence(String countryOfResidence) {
		this.countryOfResidence = countryOfResidence;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setDocumentsVerified(Short documentsVerified) {
		this.documentsVerified = documentsVerified;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setEmbossedName(String embossedName) {
		this.embossedName = embossedName;
	}

	public void setEmirates(Short emirates) {
		this.emirates = emirates;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setIdExpiryDate(String idExpiryDate) {
		this.idExpiryDate = idExpiryDate;
	}

	public void setIdIssueCountryId(String idIssueCountryId) {
		this.idIssueCountryId = idIssueCountryId;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public void setIdType(Short idType) {
		this.idType = idType;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setPcif(String pcif) {
		this.pcif = pcif;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public void setPrefixTitle(Integer prefixTitle) {
		this.prefixTitle = prefixTitle;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public void setVisaExpiryDate(String visaExpiryDate) {
		this.visaExpiryDate = visaExpiryDate;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}
}
