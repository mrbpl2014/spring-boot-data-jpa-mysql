package com.fabmagnati.mbm.cardservices.spend_limit;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.spend_limit.SpendLimitValidationRequest;
import com.fabmagnati.mbm.cardservices.spend_limit.SpendLimitValidationResponse;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class SpendLimitValidation {

    public  SpendLimitValidationResponse validateSpendLimit(Map<String, String> headers,
                                                                  SpendLimitValidationRequest request) throws SQLException {
        try (Connection connection = Datasource.getConnection();
             CallableStatement callableStatement = connection.prepareCall(
                     "{call proc_validate_spendLimit_wallet(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {
            callableStatement.registerOutParameter("@po_vc_cardId", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_iban", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_availableBalance", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_currentBalance", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_cardStatus", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_productDescription", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_productType", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_firstName", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_middleName", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_lastName", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_possibleSpendAmount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errorText", Types.VARCHAR);
            
            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
            callableStatement.setShort("@pi_ti_inquiryMode", (short) request.getInqMode());
            callableStatement.setString("@pi_vc_value", request.getValue());            

            callableStatement.execute();

            SpendLimitValidationResponse response = new SpendLimitValidationResponse();

            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));
            response.setAvailableBalance(callableStatement.getBigDecimal("@po_nm_availableBalance"));
            response.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_currentBalance"));
            response.setCardId(callableStatement.getString("@po_vc_cardId"));
            response.setIban(callableStatement.getString("@po_vc_iban"));
            response.setCardStatus(callableStatement.getString("@po_vc_cardStatus"));
            response.setProductDescription(callableStatement.getString("@po_vc_productDescription"));
            response.setProductType(callableStatement.getInt("@po_i_productType"));
            response.setFirstName(callableStatement.getString("@po_vc_firstName"));
            response.setMiddleName(callableStatement.getString("@po_vc_middleName"));
            response.setLastName(callableStatement.getString("@po_vc_lastName"));
            response.setPossibleSpendAmount(callableStatement.getBigDecimal("@po_nm_possibleSpendAmount"));
            return response;
        }
    }

}
