package com.fabmagnati.mbm.cardservices.pos_limit_inquiry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class POSLimitInquiryRequest {

    private int inqMode;
    @NotNull(message = "value must not be null")
    @NotEmpty(message = "value must not be  empty")
    private String value;
}
