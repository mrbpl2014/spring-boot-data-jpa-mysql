package com.fabmagnati.mbm.cardservices.kycUpload;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import com.fasterxml.jackson.databind.JsonNode;

public class KycUploadService {
	private static final Logger LOGGER = LoggerFactory.getLogger(KycUploadService.class);

	public static DmsConfiguration getDMSConfiguration(Map<String, String> headers, KycUploadRequest kycUploadRequest)
			throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection.prepareCall(
						"{call Proc_getDMS_configuration_v2(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@po_vc_requestId", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_sourceSystemName", Types.VARCHAR);
			callableStatement.registerOutParameter("@pio_vc_targetPathToUpload", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_fileName", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_fileType", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_objectPath", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_objectfolder", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_dirDtlAtFoldName", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_dirDtlAtAclName", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_dirDtlAtAclDomain", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_documentType", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAtteId", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttCifNo", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttKeyWords", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttAclName", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttAclDomain", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttAclDocType", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttAclObjName", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_vc_docDtlAttAclCardId", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.setInt("@pi_ti_txnsource", Integer.parseInt(headers.get("transactionsource")));
			callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.setString("@pi_vc_clientIdentifier", headers.get("channelid"));
			callableStatement.setString("@pio_vc_targetPathToUpload", kycUploadRequest.getCardId());
			callableStatement.setShort("@pi_si_txnType", (short) 0);
			callableStatement.execute();
			if (!(callableStatement.getInt("@po_i_errorCode") == 0)) {
				throw new ElpasoException(callableStatement.getInt("@po_i_errorCode"),
						callableStatement.getString("@po_vc_errortext"), headers.get("transactionid"));
			}
			DmsConfiguration dmsConfiguration = new DmsConfiguration();
			dmsConfiguration.setRequestId(callableStatement.getString("@po_vc_requestId"));
			dmsConfiguration.setSourceSystemName(callableStatement.getString("@po_vc_sourceSystemName"));
			dmsConfiguration.setTargetPathToUpload(callableStatement.getString("@pio_vc_targetPathToUpload"));
			dmsConfiguration.setObjectPath(callableStatement.getString("@po_vc_objectPath"));
			dmsConfiguration.setObjectFolder(callableStatement.getString("@po_vc_objectfolder"));
			DirectoryDetails directoryDetails = new DirectoryDetails();
			directoryDetails.setFolderName(callableStatement.getString("@po_vc_dirDtlAtFoldName"));
			directoryDetails.setAclName(callableStatement.getString("@po_vc_dirDtlAtAclName"));
			directoryDetails.setAclDomain(callableStatement.getString("@po_vc_dirDtlAtAclDomain"));
			dmsConfiguration.setDirDetails(directoryDetails);
			dmsConfiguration.setDocumentType(callableStatement.getString("@po_vc_documentType"));
			DocumentDetails documentDetails = new DocumentDetails();
			documentDetails.setEmiratesId(callableStatement.getString("@po_vc_docDtlAtteId"));
			documentDetails.setElpasaCif(callableStatement.getString("@po_vc_docDtlAttCifNo"));
			documentDetails.setKeywords(callableStatement.getString("@po_vc_docDtlAttKeyWords"));
			documentDetails.setAclName(callableStatement.getString("@po_vc_docDtlAttAclName"));
			documentDetails.setAclDomain(callableStatement.getString("@po_vc_docDtlAttAclDomain"));
			documentDetails.setDocumentType(callableStatement.getString("@po_vc_docDtlAttAclDocType"));
			documentDetails.setObjectName(callableStatement.getString("@po_vc_docDtlAttAclObjName"));
			documentDetails.setAclCardId(callableStatement.getString("@po_vc_docDtlAttAclCardId"));
			dmsConfiguration.setDocDetails(documentDetails);
			dmsConfiguration.setFileName(callableStatement.getString("@po_vc_fileName"));
			dmsConfiguration.setFileType(callableStatement.getString("@po_vc_fileType"));
			dmsConfiguration.setErrorCode(callableStatement.getString("@po_i_errorCode"));
			dmsConfiguration.setErrorText(callableStatement.getString("@po_vc_errortext"));
			LOGGER.info("Transaction Id: {} Dms configuration: {}", headers.get("transactionid"),
					dmsConfiguration.toString());
			return dmsConfiguration;
		}
	}

	public static KycUploadResponse updateDocumentUploadStatus(Map<String, String> headers,
			KycUploadRequest kycUploadRequest, DmsConfiguration dmsConfiguration, JsonNode node) throws SQLException {
		try (Connection connection = Datasource.getConnection();
				CallableStatement callableStatement = connection
						.prepareCall("{call Proc_setDMSuploadFlag_v2(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {
			callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
			callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
			callableStatement.setInt("@pi_ti_txnsource", Integer.parseInt(headers.get("transactionsource")));
			callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
			callableStatement.setTimestamp("@pi_dt_transactionDateTime",
					Timestamp.valueOf(headers.get("transactiondatetime")));
			callableStatement.setString("@pi_vc_clientIdentifer", headers.get("channelid"));
			callableStatement.setString("@pi_vc_cardno", "");
			if (!node.get("Body").get("UploadDocumentResponse").get("status").textValue().equalsIgnoreCase("FAILURE")) {
				callableStatement.setString("@pi_c_newstatus", "Y");
			} else {
				callableStatement.setString("@pi_c_newstatus", "N");
			}
			callableStatement.setString("@pi_vc_cardid", kycUploadRequest.getCardId());
			callableStatement.setShort("@pi_si_txntype", (short) 0);
			callableStatement.execute();
			LOGGER.info("Transaction Id: {} Update document status response: {}", headers.get("transactionid"),
					callableStatement.getString("@po_vc_errortext"));
			KycUploadResponse response = new KycUploadResponse();
			response.setDocumentId("");
			if (!node.get("Body").get("UploadDocumentResponse").get("status").textValue().equalsIgnoreCase("FAILURE")) {
				if (node.get("Body").get("UploadDocumentResponse").get("status").textValue()
						.equalsIgnoreCase("SUCCESS")) {
					response.setDocumentId(
							node.get("Body").get("UploadDocumentResponse").get("data").get("documentID").textValue());
				} else {
					response.setDocumentId("");
				}
				response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
				response.setErrorText(callableStatement.getString("@po_vc_errortext"));
			} else {
				response.setDocumentId("");
				response.setErrorCode(
						node.get("Body").get("UploadDocumentResponse").get("error").get("code").textValue());
				response.setErrorText(
						node.get("Body").get("UploadDocumentResponse").get("error").get("description").textValue());
			}
			return response;
		}
	}

	public static XMLGregorianCalendar getGregorianCalendarFormat(String dateStr)
			throws ParseException, DatatypeConfigurationException {
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = format.parse(dateStr);

		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);

		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
	}

	public static String uploadDocument(DmsConfiguration dmsConfiguration, KycUploadRequest kycUploadRequest,
			Map<String, String> headers) throws DatatypeConfigurationException, ParseException, IOException {
		String payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
				+ "\t<soapenv:Body>\n" + "\t<mes:UploadDocumentRequest\n"
				+ "\txmlns:mes=\"http://services.fgb.com/doc/message\"\n" + "\txmlns:ser=\"http://services.fgb.com/\"\n"
				+ "\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" + "\t<ser:requestId>"
				+ dmsConfiguration.getRequestId() + "</ser:requestId>\n" + "\t<ser:sourceSystem>"
				+ dmsConfiguration.getSourceSystemName() + "</ser:sourceSystem>\n" + "\t<ser:requestTime>"
				+ getGregorianCalendarFormat(headers.get("transactiondatetime")).toXMLFormat() + "</ser:requestTime>\n"
				+ "\t<ser:data xsi:type=\"mes:UploadDocumentRequestType\">\n" + "\t<targetPath>"
				+ dmsConfiguration.getTargetPathToUpload() + "</targetPath>\n" + "\t<directoryDetails>\n"
				+ "\t<directoryAttributes>\n" + "\t<objectPath>" + dmsConfiguration.getObjectPath() + "</objectPath>\n"
				+ "\t<objectType>" + dmsConfiguration.getObjectFolder() + "</objectType>\n" + "\t<objectAttributes>\n"
				+ "\t<name>object_name</name>\n" + "\t<value>" + dmsConfiguration.getDocDetails().getAclCardId()
				+ "</value>\n" + "\t</objectAttributes>\n" + "\t<objectAttributes>\n" + "\t<name>acl_name</name>\n"
				+ "\t<value>" + dmsConfiguration.getDirDetails().getAclName() + "</value>\n" + "\t</objectAttributes>\n"
				+ "\t<objectAttributes>\n" + "\t<name>acl_domain</name>\n" + "\t<value>"
				+ dmsConfiguration.getDirDetails().getAclDomain() + "</value>\n" + "\t</objectAttributes>\n"
				+ "\t</directoryAttributes>\n" + "\t</directoryDetails>\n" + "\t<documentDetails>\n"
				+ "\t<documentType>" + dmsConfiguration.getDocumentType() + "</documentType>\n"
				+ "\t<documentAttributes>\n" + "\t<name>object_name</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getObjectName() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>emirates_id</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getEmiratesId() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>keywords</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getKeywords() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>type_of_document</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getDocumentType() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>customer_id</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getElpasaCif() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>card_id</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getAclCardId() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>customer_name</name>\n" + "\t<value></value>\n"
				+ "\t</documentAttributes>\n" + "\t<documentAttributes>\n" + "\t<name>acl_name</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getAclName() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>acl_domain</name>\n" + "\t<value>"
				+ dmsConfiguration.getDocDetails().getAclDomain() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<documentAttributes>\n" + "\t<name>source_system</name>\n" + "\t<value>"
				+ dmsConfiguration.getSourceSystemName() + "</value>\n" + "\t</documentAttributes>\n"
				+ "\t<attachment>\n" + "\t<fileName>" + dmsConfiguration.getFileName() + "</fileName>\n"
				+ "\t<fileType>" + dmsConfiguration.getFileType() + "</fileType>\n" + "\t<content>"
				+ kycUploadRequest.getContent() + "</content>\n" + "\t</attachment>\n" + "\t</documentDetails>\n"
				+ "\t</ser:data>\n" + "\t</mes:UploadDocumentRequest>\n" + "\t</soapenv:Body>\n"
				+ "\t</soapenv:Envelope>";
		LOGGER.info("DMS Service payload:\n{}", payload);
		String dmsServiceUrl = System.getenv("DMS_SERVICE_URL");
		URL url = new URL(dmsServiceUrl);
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "text/xml");
		connection.setRequestProperty("Accept", "text/xml");
		connection.setDoOutput(true);
		try (OutputStream os = connection.getOutputStream()) {
			byte[] input = payload.getBytes(StandardCharsets.UTF_8);
			os.write(input, 0, input.length);
		}
		LOGGER.info("DMS service response code: {}", connection.getResponseCode());
		if (100 <= connection.getResponseCode() && connection.getResponseCode() <= 399) {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("DMS service response:\n{}", response);
				return response.toString();
			}
		} else {
			try (BufferedReader br = new BufferedReader(
					new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))) {
				StringBuilder response = new StringBuilder();
				String responseLine = null;
				while ((responseLine = br.readLine()) != null) {
					response.append(responseLine.trim());
				}
				LOGGER.info("DMS service response:\n{}", response);
				return response.toString();
			}
		}
	}
}
