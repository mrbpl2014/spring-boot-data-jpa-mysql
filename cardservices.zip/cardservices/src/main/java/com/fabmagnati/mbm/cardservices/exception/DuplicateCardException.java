package com.fabmagnati.mbm.cardservices.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DuplicateCardException extends RuntimeException {
	private String cardId;
	private Integer errorCode;
	private String errorText;
	private String transactionId;
	private String cardNumber;



}
