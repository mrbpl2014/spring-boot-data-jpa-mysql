package com.fabmagnati.mbm.cardservices.transaction_history;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@ToString
public class TransactionHistoryRequest {

    private int requestType;
    @NotNull
    @NotEmpty
    private String cardId;
    @NotNull
    @NotEmpty
    private String startDate;
    @NotNull
    @NotEmpty
    private String endDate;
    private int numberOfTxns;

}
