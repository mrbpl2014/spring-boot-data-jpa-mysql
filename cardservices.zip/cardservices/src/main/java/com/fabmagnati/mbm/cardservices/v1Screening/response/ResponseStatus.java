package com.fabmagnati.mbm.cardservices.v1Screening.response;

import java.util.List;

public class ResponseStatus {
	public List<ErrorDetail> errorDetails;
	public MetaData metaData;
	public String status;
	public String statusMessage;

	public List<ErrorDetail> getErrorDetails() {
		return errorDetails;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public String getStatus() {
		return status;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setErrorDetails(List<ErrorDetail> errorDetails) {
		this.errorDetails = errorDetails;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	@Override
	public String toString() {
		return "ResponseStatus{" + "status='" + status + '\'' + ", statusMessage='" + statusMessage + '\''
				+ ", errorDetails=" + errorDetails + ", metaData=" + metaData + '}';
	}
}
