package com.fabmagnati.mbm.cardservices.load_limit_validation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoadLimitValidationResponse {
    private BigDecimal availableBalance;
    private String cardId;
    private String cardStatus;
    private BigDecimal currentBalance;
    private String errorCode;
    private String errorText;
    private String firstName;
    private String iban;
    private String lastName;
    private String middleName;
    private BigDecimal possibleLoadAmount;
    private String productDescription;
    private int productType;
    private int topupCounter;
    private BigDecimal totalFeeAmount;


}
