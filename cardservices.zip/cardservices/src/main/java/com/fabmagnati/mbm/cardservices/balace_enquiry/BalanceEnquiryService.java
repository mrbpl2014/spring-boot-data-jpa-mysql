/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.balace_enquiry;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class BalanceEnquiryService {

    public BalanceEnquiryResponse balanceEnquiry(Map<String, String> header, BalanceEnquiryRequest request)
            throws SQLException {

        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall(
                "{call proc_get_cardbalanceinquiry_MBM(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {

            callableStatement.registerOutParameter("@po_vc_cardId", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_cardno", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_iban", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_availablebal", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_currentbal", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_lasttopupamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_lasttopupdate", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_nm_lasttxnamount", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_vc_lasttxndate", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_errorcode", Types.INTEGER);

            callableStatement.setString("@pi_vc_transactionIdentifier", header.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(header.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifer", header.get("clientidentifier"));
            callableStatement.setShort("@pi_ti_inqmode", (short) request.getInqMode());
            callableStatement.setString("@pi_vc_value", request.getValue());

            callableStatement.execute();

            BalanceEnquiryResponse response = new BalanceEnquiryResponse();
            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorcode")));
            response.setErrorText(callableStatement.getString("@po_vc_errortext"));
            response.setCardId(callableStatement.getString("@po_vc_cardId"));
            response.setAvailableBalance(callableStatement.getBigDecimal("@po_nm_availablebal"));
            response.setCurrentBalance(callableStatement.getBigDecimal("@po_nm_currentbal"));
            response.setLastTopUpAmount(callableStatement.getBigDecimal("@po_nm_lasttopupamount"));
            response.setLastTopUpDate(callableStatement.getString("@po_vc_lasttopupdate"));
            response.setLastTransactionAmount(callableStatement.getBigDecimal("@po_nm_lasttxnamount"));
            response.setLastTransactionDate(callableStatement.getString("@po_vc_lasttxndate"));
            response.setCardNumber(callableStatement.getString("@po_vc_cardno"));
            response.setIban(callableStatement.getString("@po_vc_iban"));

            return response;
        }
    }
}
