package com.fabmagnati.mbm.cardservices.v1Screening.response;

public class ErrorDetail {
	public String errorCode;
	public String errorDesc;
}
