package com.fabmagnati.mbm.cardservices.card_replacement;


import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.exception.ElpasoException;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.Map;

@Service
public class CardReplacementService {

    public CardReplacementResponse cardReplacement(Map<String, String> headers, CardReplacementRequest request) throws SQLException {
        try (Connection connection = Datasource.getConnection();
             CallableStatement callableStatement = connection
                     .prepareCall("{call proc_u_cardReplacement_MBM(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {
            callableStatement.registerOutParameter("@pio_vc_cardId", Types.VARCHAR);
            callableStatement.registerOutParameter("@pio_vc_iban", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_newCardId", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_vc_newCardno", Types.VARCHAR);
            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
            
            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                    Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
            callableStatement.setString("@pi_vc_reason", request.getReason());
            callableStatement.setString("@pio_vc_cardId", request.getCardId());
            callableStatement.setString("@pio_vc_iban", request.getIban());
            callableStatement.execute();
            if ((callableStatement.getInt("@po_i_errorcode") != 0)) {
                throw new ElpasoException(callableStatement.getInt("@po_i_errorcode"),
                        callableStatement.getString("@po_vc_errortext"), headers.get("transactionid"));
            }
            CardReplacementResponse response = new CardReplacementResponse();
            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));
            response.setOldCardId(callableStatement.getString("@pio_vc_cardId"));
            response.setNewCardId(callableStatement.getString("@po_vc_newCardId"));
            response.setIban(callableStatement.getString("@pio_vc_iban"));
            return response;
        }
    }
}
