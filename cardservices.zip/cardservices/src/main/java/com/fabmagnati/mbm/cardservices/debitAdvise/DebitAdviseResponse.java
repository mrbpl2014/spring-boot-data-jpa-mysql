package com.fabmagnati.mbm.cardservices.debitAdvise;

import java.math.BigDecimal;

public class DebitAdviseResponse {
	private Integer errorCode;
	private String errorText;
	private BigDecimal availableBalance;
	private BigDecimal currentBalance;
	private String cardId;

	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}

	public String getCardId() {
		return cardId;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

}
