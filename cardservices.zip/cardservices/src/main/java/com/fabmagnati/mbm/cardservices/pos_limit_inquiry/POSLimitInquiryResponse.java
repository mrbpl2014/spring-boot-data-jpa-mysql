package com.fabmagnati.mbm.cardservices.pos_limit_inquiry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class POSLimitInquiryResponse {

    private String errorCode;
    private String errorText;
    private BigDecimal maxpossingletxnlimit;
    private BigDecimal dailyPosLimit;
    private BigDecimal monthlyPosLimit;
    private String productDescription;
    private int productType;
    private String cardId;
    private String iban;
}
