package com.fabmagnati.mbm.cardservices.debit_transaction;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@ToString
public class DebitTxnRequest {
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String authorizationCode;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    @NotBlank
    private String cardId;
    @NotNull
    private BigDecimal equivalentAmount;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    @NotBlank
    private String equivalentCurrency;
    private BigDecimal feeAmount;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String feeDescription;
    private Short feeType;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String merchantId;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String merchantLocation;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String merchantName;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String onlineHostReferenceNo;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    @NotBlank
    private String remarks;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String rrn;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String sourceTxnReferenceNo;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String terminalId;
    @NotNull
    private BigDecimal transactionAmount;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    @NotBlank
    private String transactionCurrency;
    @NotNull
    private BigDecimal transactionRate;
    @NotNull
    private Short transactionType;
    @Pattern(regexp = "^[A-Za-z0-9 /@_-]*$")
    private String txnReferenceNo;

}
