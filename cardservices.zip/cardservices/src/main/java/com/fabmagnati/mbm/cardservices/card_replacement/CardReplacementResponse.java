package com.fabmagnati.mbm.cardservices.card_replacement;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardReplacementResponse {

    private String cardNumber;
    private String errorCode;
    private String errorText;
    private String iban;
    private String newCardId;
    private String oldCardId;

}
