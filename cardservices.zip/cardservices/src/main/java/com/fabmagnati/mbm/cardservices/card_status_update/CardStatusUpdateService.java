/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.card_status_update;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CardStatusUpdateService {

        private static final Logger logger = LoggerFactory.getLogger(CardStatusUpdateService.class);

        public UpdateCardStatusResponse updateCardStatus(Map<String, String> headers, UpdateCardStatusRequest request)
                throws SQLException {
            try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall(
                    "{call proc_setcardstatus_MBM(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}")) {

                callableStatement.registerOutParameter("@po_vc_errortext", Types.VARCHAR);
                callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
                callableStatement.registerOutParameter("@po_i_txnid#", Types.INTEGER);

                callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
                callableStatement.setTimestamp("@pi_dt_transactionDateTime",
                        Timestamp.valueOf(headers.get("transactiondatetime")));
                callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
                callableStatement.setShort("@pi_ti_txnsource", (short) 0);
                callableStatement.setString("@pi_vc_cardno", "");
                callableStatement.setShort("@pi_ti_newstatus", (short) request.getNewStatus());
                callableStatement.setString("@pi_vc_reasontext", request.getReasonText());
                callableStatement.setShort("@pi_ti_checkexpiryflag", (short) 0);
                callableStatement.setString("@pi_c_expirydate", "");
                callableStatement.setString("@pi_vc_cardid", request.getCardId());
                callableStatement.setShort("@pi_ti_reasonkey#", (short) 0);
                callableStatement.setString("@pi_vc_Makerid", "");
                callableStatement.setString("@pi_vc_sourcetxnref", "");
                callableStatement.execute();

                UpdateCardStatusResponse response = new UpdateCardStatusResponse();
                response.setErrorCode(callableStatement.getInt("@po_i_errorCode"));
                response.setErrorText(callableStatement.getString("@po_vc_errortext"));

                logger.debug("TRANSACTION ID: {} UPDATE CARD STATUS RESPONSE:{}", headers.get("transactionid"), response);

                return response;
            }
        }

}
