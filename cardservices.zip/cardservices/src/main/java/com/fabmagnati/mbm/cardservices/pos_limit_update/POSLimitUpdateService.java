/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fabmagnati.mbm.cardservices.pos_limit_update;

import com.fabmagnati.mbm.cardservices.datasource.Datasource;
import com.fabmagnati.mbm.cardservices.pos_limit_update.POSLimitUpdateRequest;
import com.fabmagnati.mbm.cardservices.pos_limit_update.POSLimitUpdateResponse;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 *
 * @author Hariharasudhan
 */
@Service
public class POSLimitUpdateService {

    public POSLimitUpdateResponse posLimitUpdate(Map<String, String> headers, POSLimitUpdateRequest request) throws SQLException {

        try ( Connection connection = Datasource.getConnection();  CallableStatement callableStatement = connection.prepareCall("{call proc_u_PosLimitsUpdate_wallet(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");) {

            callableStatement.registerOutParameter("@pio_nm_maxPosSingleTxnLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@pio_nm_dailyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@pio_nm_monthlyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_oldMaxPosSingleTxnLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_oldDailyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_nm_oldMonthlyPosLimit", Types.NUMERIC);
            callableStatement.registerOutParameter("@po_i_errorCode", Types.INTEGER);
            callableStatement.registerOutParameter("@po_vc_errorText", Types.VARCHAR);

            callableStatement.setString("@pi_vc_transactionIdentifier", headers.get("transactionid"));
            callableStatement.setTimestamp("@pi_dt_transactionDateTime", Timestamp.valueOf(headers.get("transactiondatetime")));
            callableStatement.setString("@pi_vc_clientIdentifier", headers.get("clientidentifier"));
            callableStatement.setString("@pi_vc_cardId", request.getCardId());
            callableStatement.setString("@pio_vc_iban", request.getIban());
            callableStatement.setBigDecimal("@pio_nm_maxPosSingleTxnLimit", request.getMaxPosSingleTxnLimit());
            callableStatement.setBigDecimal("@pio_nm_dailyPosLimit", request.getDailyposLimit());
            callableStatement.setBigDecimal("@pio_nm_monthlyPosLimit", request.getMonthlyposLimit());

            callableStatement.execute();

            POSLimitUpdateResponse response = new POSLimitUpdateResponse();

            response.setErrorCode(String.valueOf(callableStatement.getInt("@po_i_errorCode")));
            response.setErrorText(callableStatement.getString("@po_vc_errorText"));
            response.setOldMaxpossingletxnlimit(callableStatement.getBigDecimal("@po_nm_oldMaxPosSingleTxnLimit"));
            response.setNewMaxpossingletxnlimit(callableStatement.getBigDecimal("@pio_nm_maxPosSingleTxnLimit"));
            response.setOldDailyposlimit(callableStatement.getBigDecimal("@po_nm_oldDailyPosLimit"));
            response.setNewDailyposlimit(callableStatement.getBigDecimal("@pio_nm_dailyPosLimit"));
            response.setOldMonthlyposlimit(callableStatement.getBigDecimal("@po_nm_oldMonthlyPosLimit"));
            response.setNewMonthlyposlimit(callableStatement.getBigDecimal("@pio_nm_monthlyPosLimit"));

            return response;
        }
    }

}
